"""
고급 게임 유틸리티
경로 이동, NPC 상호작용, 인벤토리 관리 등
"""

import pyautogui
import time
import random
from image_utils import ImageRecognition

class PathNavigator:
    """경로 이동 시스템 (웨이포인트)"""

    def __init__(self):
        self.img_rec = ImageRecognition()

    def move_to_position(self, x, y, click_delay=0.5):
        """특정 위치로 이동 (클릭)"""
        pyautogui.click(x, y)
        time.sleep(click_delay)

    def follow_path(self, waypoints, delay_per_point=2.0):
        """
        웨이포인트를 따라 이동

        Args:
            waypoints: [(x, y), ...] 경로 좌표 리스트
            delay_per_point: 각 지점 사이 대기 시간
        """
        print(f"경로 이동 시작: {len(waypoints)}개 지점")

        for i, (x, y) in enumerate(waypoints, 1):
            print(f"[{i}/{len(waypoints)}] 이동 중... ({x}, {y})")
            self.move_to_position(x, y)
            time.sleep(delay_per_point + random.uniform(-0.5, 0.5))

        print("경로 이동 완료!")

    def move_and_wait(self, x, y, wait_image=None, timeout=10):
        """
        이동하고 특정 이미지가 나타날 때까지 대기

        Args:
            x, y: 이동할 좌표
            wait_image: 기다릴 이미지 (None이면 그냥 대기)
            timeout: 최대 대기 시간
        """
        self.move_to_position(x, y)

        if wait_image:
            pos = self.img_rec.wait_for_image(wait_image, timeout)
            return pos is not None
        else:
            time.sleep(2)
            return True


class NPCInteraction:
    """NPC 상호작용"""

    def __init__(self):
        self.img_rec = ImageRecognition()

    def talk_to_npc(self, npc_x, npc_y, interaction_key='f'):
        """
        NPC와 대화

        Args:
            npc_x, npc_y: NPC 위치
            interaction_key: 상호작용 키 (보통 F, E, Space 등)
        """
        print(f"NPC 클릭... ({npc_x}, {npc_y})")
        pyautogui.click(npc_x, npc_y)
        time.sleep(0.5)

        print(f"상호작용 키 '{interaction_key}' 누르기")
        pyautogui.press(interaction_key)
        time.sleep(1)

    def click_dialog_option(self, option_number=1):
        """
        대화 옵션 선택

        Args:
            option_number: 선택할 옵션 번호 (1부터 시작)
        """
        print(f"대화 옵션 {option_number} 선택")
        pyautogui.press(str(option_number))
        time.sleep(1)

    def skip_dialog(self, skip_key='space', times=5):
        """
        대화 넘기기

        Args:
            skip_key: 대화 넘김 키
            times: 반복 횟수
        """
        print("대화 넘기는 중...")
        for _ in range(times):
            pyautogui.press(skip_key)
            time.sleep(0.3)

    def receive_blessing(self, npc_position, blessing_option=1):
        """
        NPC에게 축복 받기

        Args:
            npc_position: (x, y) NPC 위치
            blessing_option: 축복 옵션 번호
        """
        print("축복 받는 중...")
        self.talk_to_npc(npc_position[0], npc_position[1])
        time.sleep(1)

        self.click_dialog_option(blessing_option)
        time.sleep(1)

        self.skip_dialog()
        pyautogui.press('esc')  # 대화 창 닫기
        print("축복 완료!")


class InventoryManager:
    """인벤토리 관리"""

    def __init__(self):
        self.img_rec = ImageRecognition()
        self.inventory_key = 'i'

    def open_inventory(self):
        """인벤토리 열기"""
        print("인벤토리 열기")
        pyautogui.press(self.inventory_key)
        time.sleep(1)

    def close_inventory(self):
        """인벤토리 닫기"""
        print("인벤토리 닫기")
        pyautogui.press('esc')
        time.sleep(0.5)

    def is_inventory_full(self, full_indicator_image=None, full_color=None, check_position=None):
        """
        인벤토리가 가득 찼는지 확인

        Args:
            full_indicator_image: "인벤토리 가득 찼습니다" 이미지
            full_color: 특정 위치의 색상으로 확인 (R, G, B)
            check_position: 색상 확인할 위치 (x, y)
        """
        if full_indicator_image:
            pos = self.img_rec.find_image(full_indicator_image)
            return pos is not None

        if full_color and check_position:
            return self.img_rec.is_color_match(
                check_position[0],
                check_position[1],
                full_color
            )

        return False

    def sell_all_items(self, shop_position, sell_button_position):
        """
        모든 아이템 판매

        Args:
            shop_position: (x, y) 상점 NPC 위치
            sell_button_position: (x, y) "모두 판매" 버튼 위치
        """
        print("상점에서 판매 시작...")

        # 상점 NPC 클릭
        pyautogui.click(shop_position[0], shop_position[1])
        time.sleep(1)

        # 판매 버튼 클릭
        pyautogui.click(sell_button_position[0], sell_button_position[1])
        time.sleep(1)

        # 확인 버튼 (보통 엔터 또는 특정 버튼)
        pyautogui.press('enter')
        time.sleep(1)

        # 상점 닫기
        pyautogui.press('esc')
        time.sleep(0.5)

        print("판매 완료!")


class MobFinder:
    """몹 찾기 및 자동 사냥"""

    def __init__(self):
        self.img_rec = ImageRecognition()

    def find_mob_by_image(self, mob_image_path, search_region=None):
        """
        이미지로 몹 찾기

        Args:
            mob_image_path: 몹 이미지 파일 경로
            search_region: 검색할 영역 (x, y, width, height)

        Returns:
            (x, y) 몹 위치 또는 None
        """
        return self.img_rec.find_image(mob_image_path, search_region)

    def find_all_mobs(self, mob_image_path, search_region=None):
        """
        화면에 있는 모든 몹 찾기

        Returns:
            [(x, y), ...] 몹 위치 리스트
        """
        return self.img_rec.find_all_images(mob_image_path, search_region)

    def scan_area_for_mobs(self, scan_positions):
        """
        특정 영역들을 순회하며 몹 찾기

        Args:
            scan_positions: [(x, y), ...] 스캔할 위치들

        Returns:
            bool: 몹을 찾았는지 여부
        """
        for x, y in scan_positions:
            pyautogui.click(x, y)
            time.sleep(0.5)

            # 여기서 몹 발견 체크 (색상, 이미지 등)
            # 실제 구현은 게임에 따라 다름

        return False

    def attack_nearest_mob(self, mob_positions, attack_key='1'):
        """
        가장 가까운 몹 공격

        Args:
            mob_positions: [(x, y), ...] 몹 위치 리스트
            attack_key: 공격 키
        """
        if not mob_positions:
            return False

        # 화면 중앙 기준 가장 가까운 몹 찾기
        screen_width, screen_height = pyautogui.size()
        center_x, center_y = screen_width // 2, screen_height // 2

        nearest_mob = min(mob_positions, key=lambda pos:
            ((pos[0] - center_x) ** 2 + (pos[1] - center_y) ** 2) ** 0.5
        )

        # 몹 클릭 (타겟팅)
        print(f"몹 타겟팅: {nearest_mob}")
        pyautogui.click(nearest_mob[0], nearest_mob[1])
        time.sleep(0.5)

        # 공격
        pyautogui.press(attack_key)

        return True


class SkillRotation:
    """스킬 순환 사용"""

    def __init__(self, skills):
        """
        Args:
            skills: [
                {'key': '1', 'cooldown': 0.0, 'priority': 1},
                {'key': '2', 'cooldown': 5.0, 'priority': 2},
                ...
            ]
        """
        self.skills = skills
        self.last_used = {skill['key']: 0 for skill in skills}

    def use_next_skill(self):
        """
        다음 사용 가능한 스킬 사용

        Returns:
            사용한 스킬 키 또는 None
        """
        current_time = time.time()

        # 우선순위 순으로 정렬
        sorted_skills = sorted(self.skills, key=lambda s: s.get('priority', 99))

        for skill in sorted_skills:
            key = skill['key']
            cooldown = skill.get('cooldown', 0)

            # 쿨다운 체크
            if current_time - self.last_used[key] >= cooldown:
                print(f"스킬 '{key}' 사용")
                pyautogui.press(key)
                self.last_used[key] = current_time
                return key

        return None

    def use_all_available_skills(self):
        """사용 가능한 모든 스킬 사용"""
        used_skills = []

        for skill in self.skills:
            result = self.use_next_skill()
            if result:
                used_skills.append(result)
                time.sleep(0.5)

        return used_skills
