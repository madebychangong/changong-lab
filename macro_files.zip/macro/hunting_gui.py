"""
일랜시아 스타일 게임용 자동 사냥 매크로 (GUI)
"""

import pyautogui
import time
import random
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import threading

pyautogui.FAILSAFE = True

class HuntingMacroGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("자동 사냥 매크로")
        self.root.geometry("550x750")

        self.running = False
        self.kill_count = 0
        self.current_mob_index = 0

        self.create_widgets()

    def create_widgets(self):
        """GUI 구성"""
        # 제목
        title = tk.Label(self.root, text="⚔️ 자동 사냥 매크로", font=("Arial", 16, "bold"))
        title.pack(pady=10)

        # === 몹 위치 설정 ===
        mob_frame = ttk.LabelFrame(self.root, text="몹 출현 위치 (좌표)", padding=10)
        mob_frame.pack(fill="both", expand=True, padx=10, pady=5)

        tk.Label(mob_frame, text="몹이 자주 나타나는 위치들을 입력하세요 (x,y 형식):").pack(anchor="w")
        tk.Label(mob_frame, text="예: 500,300").pack(anchor="w", pady=(0, 5))

        self.mob_positions_text = scrolledtext.ScrolledText(mob_frame, height=6, width=50)
        self.mob_positions_text.pack(fill="both", expand=True, pady=5)
        self.mob_positions_text.insert("1.0", "500,300\n600,350\n550,400\n650,320\n480,380")

        # === 스킬 설정 ===
        skill_frame = ttk.LabelFrame(self.root, text="스킬 설정", padding=10)
        skill_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(skill_frame, text="사용할 스킬 키 (쉼표로 구분):").grid(row=0, column=0, sticky="w", pady=3)
        self.skill_keys = tk.StringVar(value="1,2,3")
        tk.Entry(skill_frame, textvariable=self.skill_keys, width=30).grid(row=0, column=1, sticky="w", padx=5)

        tk.Label(skill_frame, text="스킬 사용 간격 (초):").grid(row=1, column=0, sticky="w", pady=3)
        self.skill_interval = tk.StringVar(value="0.8")
        tk.Entry(skill_frame, textvariable=self.skill_interval, width=30).grid(row=1, column=1, sticky="w", padx=5)

        tk.Label(skill_frame, text="한 몹당 공격 횟수:").grid(row=2, column=0, sticky="w", pady=3)
        self.attacks_per_mob = tk.StringVar(value="8")
        tk.Entry(skill_frame, textvariable=self.attacks_per_mob, width=30).grid(row=2, column=1, sticky="w", padx=5)

        # === 포션 설정 ===
        potion_frame = ttk.LabelFrame(self.root, text="포션 설정 (선택)", padding=10)
        potion_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(potion_frame, text="HP 포션 키 (없으면 비우기):").grid(row=0, column=0, sticky="w", pady=3)
        self.hp_potion_key = tk.StringVar(value="q")
        tk.Entry(potion_frame, textvariable=self.hp_potion_key, width=30).grid(row=0, column=1, sticky="w", padx=5)

        tk.Label(potion_frame, text="MP 포션 키 (없으면 비우기):").grid(row=1, column=0, sticky="w", pady=3)
        self.mp_potion_key = tk.StringVar(value="w")
        tk.Entry(potion_frame, textvariable=self.mp_potion_key, width=30).grid(row=1, column=1, sticky="w", padx=5)

        tk.Label(potion_frame, text="포션 사용 간격 (초):").grid(row=2, column=0, sticky="w", pady=3)
        self.potion_interval = tk.StringVar(value="30")
        tk.Entry(potion_frame, textvariable=self.potion_interval, width=30).grid(row=2, column=1, sticky="w", padx=5)

        # === 기타 설정 ===
        misc_frame = ttk.LabelFrame(self.root, text="기타 설정", padding=10)
        misc_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(misc_frame, text="몹 죽인 후 대기 시간 (초):").grid(row=0, column=0, sticky="w", pady=3)
        self.wait_after_kill = tk.StringVar(value="1.5")
        tk.Entry(misc_frame, textvariable=self.wait_after_kill, width=30).grid(row=0, column=1, sticky="w", padx=5)

        # === 통계 ===
        stats_frame = ttk.LabelFrame(self.root, text="통계", padding=10)
        stats_frame.pack(fill="x", padx=10, pady=5)

        self.stats_label = tk.Label(stats_frame, text="대기 중...", font=("Arial", 11))
        self.stats_label.pack()

        # === 로그 ===
        log_frame = ttk.LabelFrame(self.root, text="로그", padding=10)
        log_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.log_text = scrolledtext.ScrolledText(log_frame, height=6, width=50, state='disabled')
        self.log_text.pack(fill="both", expand=True)

        # === 버튼 ===
        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)

        self.start_button = tk.Button(button_frame, text="▶ 시작", bg="green", fg="white",
                                       font=("Arial", 12, "bold"), width=12, command=self.start_macro)
        self.start_button.grid(row=0, column=0, padx=5)

        self.stop_button = tk.Button(button_frame, text="■ 중지", bg="red", fg="white",
                                      font=("Arial", 12, "bold"), width=12, command=self.stop_macro, state="disabled")
        self.stop_button.grid(row=0, column=1, padx=5)

        # 도움말
        help_text = "💡 좌표 확인: python macro.py → 5번 | F9 또는 화면 모서리로 긴급 중지"
        tk.Label(self.root, text=help_text, fg="gray", font=("Arial", 9)).pack(pady=5)

    def parse_mob_positions(self):
        """몹 위치 파싱"""
        text = self.mob_positions_text.get("1.0", "end").strip()
        positions = []
        for line in text.split('\n'):
            if ',' in line:
                try:
                    x, y = line.split(',')
                    positions.append((int(x.strip()), int(y.strip())))
                except:
                    pass
        return positions

    def parse_skill_keys(self):
        """스킬 키 파싱"""
        keys = self.skill_keys.get().split(',')
        return [k.strip() for k in keys if k.strip()]

    def log(self, msg):
        """로그 출력"""
        t = time.strftime("%H:%M:%S")
        log_msg = f"[{t}] {msg}\n"

        # 터미널 출력
        print(log_msg.strip())

        # GUI 로그
        self.log_text.config(state='normal')
        self.log_text.insert('end', log_msg)
        self.log_text.see('end')
        self.log_text.config(state='disabled')

    def update_stats(self):
        """통계 업데이트"""
        text = f"처치한 몹: {self.kill_count}마리 | 현재 위치: {self.current_mob_index + 1}"
        self.stats_label.config(text=text)

    def click_mob(self, x, y):
        """몹 클릭"""
        pyautogui.click(x, y)
        time.sleep(0.5)

    def use_skill(self, skill_key):
        """스킬 사용"""
        pyautogui.press(skill_key)
        interval = float(self.skill_interval.get())
        time.sleep(interval)

    def attack_mob(self, mob_pos):
        """몹 공격"""
        x, y = mob_pos

        # 몹 클릭
        self.log(f"몹 클릭: ({x}, {y})")
        self.click_mob(x, y)

        # 스킬 사용
        skills = self.parse_skill_keys()
        attacks = int(self.attacks_per_mob.get())

        for i in range(attacks):
            skill = random.choice(skills)
            self.log(f"  스킬 '{skill}' 사용 ({i+1}/{attacks})")
            self.use_skill(skill)

        self.kill_count += 1
        self.update_stats()
        self.log(f"몹 처치 완료! (총 {self.kill_count}마리)")

        # 대기
        wait_time = float(self.wait_after_kill.get())
        time.sleep(wait_time)

    def use_potions_if_needed(self, last_potion_time):
        """포션 사용"""
        current_time = time.time()
        potion_interval = float(self.potion_interval.get())

        if (current_time - last_potion_time) >= potion_interval:
            hp_key = self.hp_potion_key.get().strip()
            mp_key = self.mp_potion_key.get().strip()

            if hp_key:
                self.log(f"HP 포션 사용 ('{hp_key}')")
                pyautogui.press(hp_key)
                time.sleep(0.5)

            if mp_key:
                self.log(f"MP 포션 사용 ('{mp_key}')")
                pyautogui.press(mp_key)
                time.sleep(0.5)

            return current_time

        return last_potion_time

    def run_macro(self):
        """매크로 실행"""
        self.log("=" * 50)
        self.log("자동 사냥 시작!")

        mob_positions = self.parse_mob_positions()
        if not mob_positions:
            self.log("⚠️  몹 위치가 설정되지 않았습니다!")
            messagebox.showerror("오류", "몹 위치를 입력하세요!")
            self.stop_macro()
            return

        self.log(f"설정: {len(mob_positions)}개 위치 순회")

        # 5초 대기
        for i in range(5, 0, -1):
            self.log(f"{i}초 후 시작...")
            time.sleep(1)

        last_potion_time = time.time()

        try:
            while self.running:
                # 포션 체크
                last_potion_time = self.use_potions_if_needed(last_potion_time)

                # 다음 몹 위치
                mob_pos = mob_positions[self.current_mob_index % len(mob_positions)]

                # 공격
                self.log(f"\n[{self.kill_count + 1}번째 몹]")
                self.attack_mob(mob_pos)

                # 다음 위치로
                self.current_mob_index += 1

                # 잠깐 대기
                time.sleep(random.uniform(0.5, 1.0))

        except Exception as e:
            self.log(f"오류: {e}")
            messagebox.showerror("오류", str(e))

        finally:
            self.log("=" * 50)
            self.log(f"자동 사냥 종료! 총 {self.kill_count}마리 처치")
            self.stop_button.config(state="disabled")
            self.start_button.config(state="normal")

    def start_macro(self):
        """매크로 시작"""
        # 검증
        try:
            float(self.skill_interval.get())
            int(self.attacks_per_mob.get())
            float(self.wait_after_kill.get())
        except ValueError:
            messagebox.showerror("오류", "숫자를 올바르게 입력하세요!")
            return

        mob_positions = self.parse_mob_positions()
        if not mob_positions:
            messagebox.showerror("오류", "몹 위치를 최소 1개 이상 입력하세요!")
            return

        self.running = True
        self.start_button.config(state="disabled")
        self.stop_button.config(state="normal")

        # 별도 쓰레드로 실행
        thread = threading.Thread(target=self.run_macro, daemon=True)
        thread.start()

    def stop_macro(self):
        """매크로 중지"""
        self.running = False
        self.log("중지 요청됨...")

if __name__ == "__main__":
    root = tk.Tk()
    app = HuntingMacroGUI(root)
    root.mainloop()
