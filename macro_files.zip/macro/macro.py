"""
RPG 게임 매크로
싱글 플레이 게임 자동화 스크립트
"""

import pyautogui
import time
import keyboard
from datetime import datetime
from activities import FishingBot, GatheringBot, CombatBot, SkillTrainingBot
from image_utils import ImageRecognition

# 안전을 위한 failsafe 설정 (마우스를 화면 모서리로 이동하면 중단)
pyautogui.FAILSAFE = True

def get_mouse_position():
    """현재 마우스 위치 확인 도구"""
    print("\n" + "=" * 60)
    print("마우스 위치 확인 모드 (Ctrl+C로 종료)")
    print("=" * 60)
    print("\n게임에서 클릭하고 싶은 위치에 마우스를 올려두면")
    print("좌표가 실시간으로 표시됩니다.\n")
    try:
        while True:
            x, y = pyautogui.position()
            rgb = pyautogui.pixel(x, y)
            print(f"\r마우스 위치: X={x:4d}, Y={y:4d} | 색상: RGB{rgb}  ", end='')
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("\n\n종료됨")

def take_screenshot():
    """스크린샷 저장"""
    img_rec = ImageRecognition()
    filepath = img_rec.save_screenshot("game_screen")
    print(f"\n스크린샷 저장 완료: {filepath}")

def run_fishing():
    """낚시 자동화 실행"""
    print("\n" + "=" * 60)
    print("낚시 자동화")
    print("=" * 60)
    print("\n설정:")
    print("- 낚시 키: F (수정하려면 activities.py 편집)")
    print("- 잡기 키: SPACE")

    duration_input = input("\n실행 시간 (분, 무제한은 엔터): ").strip()
    duration = int(duration_input) * 60 if duration_input else None

    print("\n3초 후 시작됩니다. 게임 창을 활성화하세요...")
    time.sleep(3)

    bot = FishingBot()
    print("\nF9를 눌러 중지할 수 있습니다.\n")

    try:
        bot.run(duration)
    except KeyboardInterrupt:
        bot.stop()

    stats = bot.get_stats()
    print(f"\n총 {stats['count']}회 낚시, 분당 {stats['rate_per_minute']:.1f}회")

def run_gathering():
    """채집 자동화 실행"""
    print("\n" + "=" * 60)
    print("채집 자동화")
    print("=" * 60)
    print("\n모드 선택:")
    print("1. 랜덤 위치 채집")
    print("2. 특정 위치 순회 채집")

    mode = input("\n선택 (1/2): ").strip()

    duration_input = input("실행 시간 (분, 무제한은 엔터): ").strip()
    duration = int(duration_input) * 60 if duration_input else None

    print("\n3초 후 시작됩니다. 게임 창을 활성화하세요...")
    time.sleep(3)

    bot = GatheringBot()
    print("\nF9를 눌러 중지할 수 있습니다.\n")

    try:
        if mode == "1":
            bot.run_random(duration)
        elif mode == "2":
            # 예시 위치 - 실제 게임에 맞게 수정 필요
            positions = [(500, 300), (600, 350), (550, 400)]
            print(f"순회 위치: {positions}")
            print("(실제 위치는 activities.py에서 수정하세요)")
            bot.run_with_positions(positions, duration)
    except KeyboardInterrupt:
        bot.stop()

    stats = bot.get_stats()
    print(f"\n총 {stats['count']}회 채집, 분당 {stats['rate_per_minute']:.1f}회")

def run_combat():
    """전투 자동화 실행"""
    print("\n" + "=" * 60)
    print("전투 자동화 (몹 사냥)")
    print("=" * 60)
    print("\n설정:")
    print("- 공격 키: 1, 2, 3, 4")
    print("- HP 포션: Q")
    print("- MP 포션: W")

    duration_input = input("\n실행 시간 (분, 무제한은 엔터): ").strip()
    duration = int(duration_input) * 60 if duration_input else None

    print("\n3초 후 시작됩니다. 게임 창을 활성화하세요...")
    time.sleep(3)

    bot = CombatBot()
    print("\nF9를 눌러 중지할 수 있습니다.\n")

    try:
        bot.run_combat(duration)
    except KeyboardInterrupt:
        bot.stop()

    stats = bot.get_stats()
    print(f"\n총 {stats['count']}회 전투, 분당 {stats['rate_per_minute']:.1f}회")

def run_skill_training():
    """숙련도 올리기 실행"""
    print("\n" + "=" * 60)
    print("숙련도 훈련")
    print("=" * 60)
    print("\n설정:")
    print("- 스킬 키: 1 (수정하려면 activities.py 편집)")

    duration_input = input("\n실행 시간 (분, 무제한은 엔터): ").strip()
    duration = int(duration_input) * 60 if duration_input else None

    print("\n3초 후 시작됩니다. 게임 창을 활성화하세요...")
    time.sleep(3)

    bot = SkillTrainingBot()
    print("\nF9를 눌러 중지할 수 있습니다.\n")

    try:
        bot.run(duration)
    except KeyboardInterrupt:
        bot.stop()

    stats = bot.get_stats()
    print(f"\n총 {stats['count']}회 스킬 사용, 분당 {stats['rate_per_minute']:.1f}회")

if __name__ == "__main__":
    print("\n" + "=" * 60)
    print(" " * 20 + "RPG 게임 매크로")
    print("=" * 60)
    print("\n기능 선택:")
    print("1. 낚시 자동화")
    print("2. 채집 자동화")
    print("3. 전투 자동화 (몹 사냥)")
    print("4. 숙련도 훈련")
    print("5. 마우스 위치 확인")
    print("6. 스크린샷 저장")
    print()

    choice = input("선택 (1-6): ").strip()

    if choice == "1":
        run_fishing()
    elif choice == "2":
        run_gathering()
    elif choice == "3":
        run_combat()
    elif choice == "4":
        run_skill_training()
    elif choice == "5":
        get_mouse_position()
    elif choice == "6":
        take_screenshot()
    else:
        print("잘못된 선택입니다.")
