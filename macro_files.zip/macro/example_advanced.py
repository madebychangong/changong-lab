"""
고급 매크로 사용 예시
실제 게임에 맞게 좌표와 설정을 수정하세요.
"""

from activities import AdvancedFishingBot, AdvancedCombatBot, AdvancedSkillTrainingBot
import time

# ==================== 예시 1: 고급 낚시 (낚시 → 판매 → 복귀) ====================
def example_advanced_fishing():
    """
    낚시 자동화 + 상점 판매 + 낚시터 복귀
    """
    print("=" * 60)
    print("예시: 고급 낚시 자동화 (판매 포함)")
    print("=" * 60)

    # 1. Bot 생성
    bot = AdvancedFishingBot()

    # 2. 경로 설정 (실제 게임 좌표로 변경!)
    path_to_shop = [
        (500, 400),   # 낚시터에서 첫 번째 지점
        (600, 450),   # 두 번째 지점
        (700, 500),   # 상점 앞
    ]

    path_to_fishing = [
        (700, 500),   # 상점에서 출발
        (600, 450),
        (500, 400),   # 낚시터 도착
    ]

    shop_npc = (750, 520)       # 상점 NPC 위치
    sell_button = (800, 600)    # "모두 판매" 버튼 위치

    bot.setup_paths(
        path_to_shop=path_to_shop,
        path_to_fishing=path_to_fishing,
        shop_npc=shop_npc,
        sell_button=sell_button
    )

    # 3. 낚시 개수 설정
    bot.fishes_per_trip = 15  # 15마리마다 상점 방문

    # 4. 실행
    print("\n3초 후 시작...")
    time.sleep(3)

    bot.run(duration=600)  # 10분 동안 실행


# ==================== 예시 2: 고급 전투 (몹 자동 사냥) ====================
def example_advanced_combat():
    """
    맵에서 몹 찾아서 자동 사냥
    """
    print("=" * 60)
    print("예시: 고급 전투 자동화 (몹 찾기)")
    print("=" * 60)

    # 1. Bot 생성
    bot = AdvancedCombatBot()

    # 2. 사냥터 설정
    # 몹이 자주 나타나는 위치들 (실제 게임 좌표로 변경!)
    scan_positions = [
        (500, 300),
        (600, 350),
        (550, 400),
        (450, 350),
        (650, 300),
    ]

    # 몹 이미지 경로 (옵션)
    # screenshots/ 폴더에 몹 스크린샷을 저장하고 경로 지정
    mob_image = None  # "screenshots/mob.png"

    bot.setup_hunting_area(
        scan_positions=scan_positions,
        mob_image=mob_image
    )

    # 3. 스킬 설정
    bot.attack_key = '1'
    bot.skill_keys = ['2', '3', '4', '5']

    # 4. 실행
    print("\n3초 후 시작...")
    time.sleep(3)

    bot.run_auto_hunt(duration=600)  # 10분 동안 실행


# ==================== 예시 3: 고급 숙련도 훈련 (NPC 축복) ====================
def example_advanced_training():
    """
    여러 스킬 순환 사용 + NPC에게 축복 받기
    """
    print("=" * 60)
    print("예시: 고급 숙련도 훈련 (NPC 축복)")
    print("=" * 60)

    # 1. Bot 생성
    bot = AdvancedSkillTrainingBot()

    # 2. 스킬 설정
    skills = [
        {'key': '1', 'cooldown': 0.0, 'priority': 1},   # 기본 스킬
        {'key': '2', 'cooldown': 1.5, 'priority': 2},   # 스킬 2 (쿨다운 1.5초)
        {'key': '3', 'cooldown': 3.0, 'priority': 3},   # 스킬 3 (쿨다운 3초)
        {'key': '4', 'cooldown': 5.0, 'priority': 4},   # 스킬 4 (쿨다운 5초)
    ]

    bot.setup_skills(skills)

    # 3. NPC 축복 설정 (실제 게임 좌표로 변경!)
    npc_position = (400, 300)  # NPC 위치
    blessing_interval = 120    # 2분마다 축복

    bot.setup_blessing(
        npc_position=npc_position,
        interval=blessing_interval
    )

    # 4. 실행
    print("\n3초 후 시작...")
    time.sleep(3)

    bot.run(duration=600)  # 10분 동안 실행


# ==================== 실행 예시 ====================
if __name__ == "__main__":
    print("\n고급 매크로 예시 파일")
    print("=" * 60)
    print("\n사용 방법:")
    print("1. 마우스 위치 확인으로 게임 좌표들을 파악")
    print("2. 이 파일에서 좌표들을 실제 값으로 수정")
    print("3. 원하는 예시 함수 호출")
    print("\n예시 함수:")
    print("1. example_advanced_fishing()  - 낚시 + 판매")
    print("2. example_advanced_combat()   - 자동 사냥")
    print("3. example_advanced_training() - 숙련도 훈련")
    print("\n" + "=" * 60)

    # 사용하고 싶은 예시의 주석을 해제하세요:

    # example_advanced_fishing()
    # example_advanced_combat()
    # example_advanced_training()

    print("\n⚠️  먼저 각 함수의 좌표들을 실제 게임에 맞게 수정하세요!")
    print("    python macro.py → 5번 메뉴로 좌표 확인")
