"""
옛날 게임용 전투 매크로
마우스로 몹 클릭 → 스킬 사용
"""

import pyautogui
import time
import random

# ==================== 설정 ====================

# 사냥터 설정
# 몹이 자주 나타나는 위치들 (마우스 위치 확인으로 좌표 확인!)
MOB_SPAWN_POSITIONS = [
    # (x, y),  # 몹 위치 1
    # (x, y),  # 몹 위치 2
    # (x, y),  # 몹 위치 3
]

# 스킬 설정 (게임에서 설정한 키)
ATTACK_SKILLS = ['1', '2', '3']  # 사용할 스킬 키들
SKILL_DELAY = 0.8                # 스킬 사용 간격 (초)

# 포션 사용
HP_POTION_KEY = 'q'              # HP 포션 키 (없으면 None)
MP_POTION_KEY = 'w'              # MP 포션 키 (없으면 None)
USE_POTION_INTERVAL = 30         # 몇 초마다 포션 체크

# 전투 방식
ATTACKS_PER_MOB = 8              # 한 몹당 몇 번 공격할지
WAIT_AFTER_KILL = 1.5            # 몹 죽인 후 대기 시간

# ==================================================

pyautogui.FAILSAFE = True

def log(msg):
    """로그 출력"""
    t = time.strftime("%H:%M:%S")
    print(f"[{t}] {msg}")

def click_mob(x, y):
    """몹 클릭 (타겟팅)"""
    pyautogui.click(x, y)
    time.sleep(0.5)

def use_skill(skill_key):
    """스킬 사용"""
    pyautogui.press(skill_key)
    time.sleep(SKILL_DELAY)

def attack_mob(mob_pos):
    """몹 공격"""
    x, y = mob_pos

    # 몹 클릭 (타겟팅)
    log(f"몹 클릭: ({x}, {y})")
    click_mob(x, y)

    # 스킬 사용
    for i in range(ATTACKS_PER_MOB):
        skill = random.choice(ATTACK_SKILLS)
        log(f"  스킬 '{skill}' 사용 ({i+1}/{ATTACKS_PER_MOB})")
        use_skill(skill)

    log("몹 처치 완료!")
    time.sleep(WAIT_AFTER_KILL)

def use_potion_if_needed(last_potion_time):
    """일정 시간마다 포션 사용"""
    current_time = time.time()

    if (current_time - last_potion_time) >= USE_POTION_INTERVAL:
        if HP_POTION_KEY:
            log(f"HP 포션 사용 ('{HP_POTION_KEY}')")
            pyautogui.press(HP_POTION_KEY)
            time.sleep(0.5)

        if MP_POTION_KEY:
            log(f"MP 포션 사용 ('{MP_POTION_KEY}')")
            pyautogui.press(MP_POTION_KEY)
            time.sleep(0.5)

        return current_time

    return last_potion_time

def auto_hunting(duration_minutes=None):
    """자동 사냥"""
    log("자동 사냥 시작!")
    log(f"사냥터 위치: {len(MOB_SPAWN_POSITIONS)}개")

    if not MOB_SPAWN_POSITIONS:
        log("⚠️  MOB_SPAWN_POSITIONS이 비어있습니다!")
        log("   파일을 열어서 몹 위치 좌표를 입력하세요.")
        return

    if duration_minutes:
        log(f"실행 시간: {duration_minutes}분")

    kill_count = 0
    start_time = time.time()
    last_potion_time = time.time()
    pos_index = 0

    try:
        while True:
            # 시간 체크
            if duration_minutes:
                elapsed = (time.time() - start_time) / 60
                if elapsed >= duration_minutes:
                    break

            # 포션 체크
            last_potion_time = use_potion_if_needed(last_potion_time)

            # 다음 몹 위치 선택 (순환)
            mob_pos = MOB_SPAWN_POSITIONS[pos_index % len(MOB_SPAWN_POSITIONS)]

            # 몹 공격
            log(f"\n[{kill_count + 1}번째 몹]")
            attack_mob(mob_pos)

            kill_count += 1
            pos_index += 1

            # 잠깐 대기
            time.sleep(random.uniform(0.5, 1.5))

    except KeyboardInterrupt:
        log("\n중지됨 (Ctrl+C)")

    finally:
        log("=" * 50)
        log(f"종료! 총 {kill_count}마리 처치")

# ==================== 실행 ====================
if __name__ == "__main__":
    print("=" * 60)
    print("옛날 게임용 전투 매크로")
    print("=" * 60)
    print()
    print("⚠️  먼저 설정 필요:")
    print("   1. 몹 출현 위치 (MOB_SPAWN_POSITIONS)")
    print("   2. 스킬 키 (ATTACK_SKILLS)")
    print("   3. 한 몹당 공격 횟수 (ATTACKS_PER_MOB)")
    print()
    print("💡 좌표 확인: python macro.py → 5번")
    print()

    if not MOB_SPAWN_POSITIONS:
        print("⚠️  MOB_SPAWN_POSITIONS이 비어있습니다!")
        print("   파일을 열어서 몹 위치 좌표를 입력하세요.")
        print()
        cont = input("그래도 계속? (y/n): ").strip().lower()
        if cont != 'y':
            exit()

    duration = input("실행 시간 (분, 무제한은 엔터): ").strip()
    duration = int(duration) if duration else None

    print("\n5초 후 시작... 게임 캐릭터를 사냥터에 위치시키세요!")
    for i in range(5, 0, -1):
        print(f"{i}...")
        time.sleep(1)

    auto_hunting(duration_minutes=duration)
