"""
옛날 게임용 낚시 매크로
(바람의 나라, 어둠의 전설 스타일)
"""

import pyautogui
import time
import random

# ==================== 설정 ====================

# 낚시 설정
FISHING_KEY = 'space'           # 낚시 키
FISHING_INTERVAL = 3.0          # 낚시 간격 (초) - 민첩에 맞게 조정
FISHES_BEFORE_SELL = 25         # 몇 마리마다 상점 갈지

# 상점 경로 (낚시터 → 상점)
# python macro.py → 5번으로 좌표 확인 후 입력!
PATH_TO_SHOP = [
    # (x, y),  # 1번 지점
    # (x, y),  # 2번 지점
]

# 상점 복귀 경로 (상점 → 낚시터)
PATH_TO_FISHING = [
    # (x, y),  # 1번 지점
    # (x, y),  # 낚시터
]

# 상점 NPC
SHOP_NPC_X = 0
SHOP_NPC_Y = 0

# 판매 방법 (게임에 따라 다름)
SELL_METHOD = 'button'  # 'button' 또는 'chat'

# 버튼 방식일 경우
SELL_BUTTON_X = 0
SELL_BUTTON_Y = 0

# 채팅 방식일 경우 (/판매 같은거)
SELL_CHAT_COMMAND = '/판매'

# ==================================================

pyautogui.FAILSAFE = True

def log(msg):
    """로그 출력"""
    t = time.strftime("%H:%M:%S")
    print(f"[{t}] {msg}")

def click_pos(x, y, delay=1.0):
    """위치 클릭"""
    if x == 0 and y == 0:
        log("⚠️  좌표가 설정되지 않았습니다!")
        return
    pyautogui.click(x, y)
    time.sleep(delay)

def move_along_path(path):
    """경로 따라 이동"""
    if not path:
        log("⚠️  경로가 설정되지 않았습니다!")
        return

    for i, (x, y) in enumerate(path, 1):
        log(f"이동 {i}/{len(path)}: ({x}, {y})")
        click_pos(x, y, delay=2.0 + random.uniform(-0.5, 0.5))

def fish_once():
    """한 번 낚시"""
    pyautogui.press(FISHING_KEY)
    time.sleep(FISHING_INTERVAL + random.uniform(-0.3, 0.3))

def sell_fish():
    """물고기 판매"""
    log("=" * 50)
    log("상점으로 이동 시작!")

    # 1. 상점으로 이동
    move_along_path(PATH_TO_SHOP)

    # 2. 상점 NPC 클릭
    log("상점 NPC 클릭")
    click_pos(SHOP_NPC_X, SHOP_NPC_Y, delay=1.5)

    # 3. 판매
    if SELL_METHOD == 'button':
        log("판매 버튼 클릭")
        click_pos(SELL_BUTTON_X, SELL_BUTTON_Y, delay=1.0)
        pyautogui.press('enter')  # 확인
        time.sleep(1)

    elif SELL_METHOD == 'chat':
        log(f"채팅 명령어: {SELL_CHAT_COMMAND}")
        pyautogui.press('enter')  # 채팅창 열기
        time.sleep(0.5)
        pyautogui.write(SELL_CHAT_COMMAND)
        time.sleep(0.5)
        pyautogui.press('enter')  # 전송
        time.sleep(1)

    # 4. 창 닫기
    pyautogui.press('esc')
    time.sleep(0.5)

    log("판매 완료!")

    # 5. 낚시터로 복귀
    log("낚시터로 복귀 중...")
    move_along_path(PATH_TO_FISHING)

    log("낚시 재개!")
    log("=" * 50)

def auto_fishing(duration_minutes=None):
    """낚시 자동화 메인"""
    log("낚시 자동화 시작!")
    log(f"설정: {FISHES_BEFORE_SELL}마리마다 판매")

    if duration_minutes:
        log(f"실행 시간: {duration_minutes}분")

    fish_count = 0
    sell_count = 0
    total_fish = 0
    start_time = time.time()

    try:
        while True:
            # 시간 체크
            if duration_minutes:
                elapsed = (time.time() - start_time) / 60
                if elapsed >= duration_minutes:
                    break

            # 낚시
            fish_once()
            fish_count += 1
            total_fish += 1

            log(f"낚시 완료 ({fish_count}/{FISHES_BEFORE_SELL}마리)")

            # 판매 타이밍
            if fish_count >= FISHES_BEFORE_SELL:
                sell_fish()
                sell_count += 1
                fish_count = 0

    except KeyboardInterrupt:
        log("\n중지됨 (Ctrl+C)")

    finally:
        log("=" * 50)
        log(f"종료! 총 {total_fish}마리 낚시, {sell_count}회 판매")

# ==================== 실행 ====================
if __name__ == "__main__":
    print("=" * 60)
    print("옛날 게임용 낚시 매크로")
    print("=" * 60)
    print()
    print("⚠️  먼저 설정 필요:")
    print("   1. 낚시 간격 (FISHING_INTERVAL)")
    print("   2. 상점 경로 좌표 (PATH_TO_SHOP, PATH_TO_FISHING)")
    print("   3. 상점 NPC 위치 (SHOP_NPC_X, SHOP_NPC_Y)")
    print()
    print("💡 좌표 확인: python macro.py → 5번")
    print()

    # 설정 확인
    if not PATH_TO_SHOP:
        print("⚠️  PATH_TO_SHOP이 비어있습니다!")
        print("   파일을 열어서 경로 좌표를 입력하세요.")
        print()
        cont = input("그래도 계속? (y/n): ").strip().lower()
        if cont != 'y':
            exit()

    duration = input("실행 시간 (분, 무제한은 엔터): ").strip()
    duration = int(duration) if duration else None

    print("\n5초 후 시작... 게임 캐릭터를 낚시터에 위치시키세요!")
    for i in range(5, 0, -1):
        print(f"{i}...")
        time.sleep(1)

    auto_fishing(duration_minutes=duration)
