"""
이미지 인식 유틸리티
화면에서 특정 이미지를 찾고 클릭하는 기능
"""

import pyautogui
import cv2
import numpy as np
from datetime import datetime
import os

class ImageRecognition:
    def __init__(self, confidence=0.8):
        """
        confidence: 이미지 매칭 정확도 (0.0 ~ 1.0)
        """
        self.confidence = confidence
        self.screenshot_dir = "screenshots"

        # 스크린샷 폴더 생성
        if not os.path.exists(self.screenshot_dir):
            os.makedirs(self.screenshot_dir)

    def find_image(self, template_path, region=None):
        """
        화면에서 이미지 찾기

        Args:
            template_path: 찾을 이미지 파일 경로
            region: 검색할 영역 (x, y, width, height) - None이면 전체 화면

        Returns:
            (x, y) 좌표 또는 None
        """
        try:
            location = pyautogui.locateOnScreen(
                template_path,
                confidence=self.confidence,
                region=region
            )

            if location:
                # 이미지 중앙 좌표 반환
                center = pyautogui.center(location)
                return (center.x, center.y)
            return None
        except Exception as e:
            print(f"이미지 찾기 실패: {e}")
            return None

    def find_all_images(self, template_path, region=None):
        """
        화면에서 모든 매칭되는 이미지 찾기

        Returns:
            [(x, y), ...] 좌표 리스트
        """
        try:
            locations = list(pyautogui.locateAllOnScreen(
                template_path,
                confidence=self.confidence,
                region=region
            ))

            centers = [pyautogui.center(loc) for loc in locations]
            return [(c.x, c.y) for c in centers]
        except Exception as e:
            print(f"이미지 찾기 실패: {e}")
            return []

    def click_image(self, template_path, region=None, clicks=1, interval=0.5):
        """
        이미지를 찾아서 클릭

        Returns:
            bool: 클릭 성공 여부
        """
        pos = self.find_image(template_path, region)
        if pos:
            pyautogui.click(pos[0], pos[1], clicks=clicks, interval=interval)
            print(f"이미지 클릭 성공: {pos}")
            return True
        else:
            print(f"이미지를 찾을 수 없음: {template_path}")
            return False

    def wait_for_image(self, template_path, timeout=10, region=None):
        """
        이미지가 나타날 때까지 대기

        Args:
            timeout: 최대 대기 시간 (초)

        Returns:
            (x, y) 좌표 또는 None
        """
        import time
        start_time = time.time()

        while time.time() - start_time < timeout:
            pos = self.find_image(template_path, region)
            if pos:
                return pos
            time.sleep(0.5)

        print(f"타임아웃: {template_path}")
        return None

    def save_screenshot(self, name="screenshot"):
        """
        스크린샷 저장

        Returns:
            저장된 파일 경로
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{name}_{timestamp}.png"
        filepath = os.path.join(self.screenshot_dir, filename)

        screenshot = pyautogui.screenshot()
        screenshot.save(filepath)

        print(f"스크린샷 저장: {filepath}")
        return filepath

    def save_region_screenshot(self, x, y, width, height, name="region"):
        """
        특정 영역의 스크린샷 저장
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{name}_{timestamp}.png"
        filepath = os.path.join(self.screenshot_dir, filename)

        screenshot = pyautogui.screenshot(region=(x, y, width, height))
        screenshot.save(filepath)

        print(f"영역 스크린샷 저장: {filepath}")
        return filepath

    def get_pixel_color(self, x, y):
        """
        특정 위치의 픽셀 색상 가져오기

        Returns:
            (R, G, B) 튜플
        """
        return pyautogui.pixel(x, y)

    def is_color_match(self, x, y, target_color, tolerance=10):
        """
        특정 위치의 색상이 목표 색상과 일치하는지 확인

        Args:
            target_color: (R, G, B) 튜플
            tolerance: 색상 오차 허용 범위
        """
        current_color = self.get_pixel_color(x, y)

        for i in range(3):
            if abs(current_color[i] - target_color[i]) > tolerance:
                return False
        return True
