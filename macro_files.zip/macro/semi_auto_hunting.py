"""
반자동 사냥 매크로
사용자가 몹 클릭 → 자동으로 스킬 사용
"""

import pyautogui
import time
import random
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from pynput import mouse, keyboard
import threading

pyautogui.FAILSAFE = True

class SemiAutoHuntingGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("반자동 사냥 매크로")
        self.root.geometry("500x650")

        self.active = False
        self.kill_count = 0
        self.attacking = False

        # 마우스/키보드 리스너
        self.mouse_listener = None
        self.keyboard_listener = None

        self.create_widgets()

    def create_widgets(self):
        """GUI 구성"""
        # 제목
        title = tk.Label(self.root, text="⚔️ 반자동 사냥 매크로", font=("Arial", 16, "bold"))
        title.pack(pady=10)

        # 설명
        desc_frame = tk.Frame(self.root, bg="lightyellow", relief="solid", borderwidth=1)
        desc_frame.pack(fill="x", padx=10, pady=5)

        desc_text = """
        🎯 사용 방법:
        1. 게임 맵을 돌아다니면서 몹 찾기
        2. 마우스 왼쪽 클릭으로 몹 선택
        3. 자동으로 스킬 사용! (8번)
        4. 다음 몹으로 이동해서 다시 클릭

        💡 F1 키로 활성화/비활성화
        """
        tk.Label(desc_frame, text=desc_text, justify="left", bg="lightyellow",
                font=("Arial", 9)).pack(padx=10, pady=10)

        # === 스킬 설정 ===
        skill_frame = ttk.LabelFrame(self.root, text="스킬 설정", padding=10)
        skill_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(skill_frame, text="스킬 키 (쉼표로 구분):").grid(row=0, column=0, sticky="w", pady=3)
        self.skill_keys = tk.StringVar(value="1,2,3")
        tk.Entry(skill_frame, textvariable=self.skill_keys, width=25).grid(row=0, column=1, sticky="w", padx=5)

        tk.Label(skill_frame, text="한 몹당 스킬 사용 횟수:").grid(row=1, column=0, sticky="w", pady=3)
        self.attacks_per_mob = tk.StringVar(value="8")
        tk.Entry(skill_frame, textvariable=self.attacks_per_mob, width=25).grid(row=1, column=1, sticky="w", padx=5)

        tk.Label(skill_frame, text="스킬 간격 (초):").grid(row=2, column=0, sticky="w", pady=3)
        self.skill_interval = tk.StringVar(value="0.8")
        tk.Entry(skill_frame, textvariable=self.skill_interval, width=25).grid(row=2, column=1, sticky="w", padx=5)

        # === 추가 설정 ===
        misc_frame = ttk.LabelFrame(self.root, text="추가 설정", padding=10)
        misc_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(misc_frame, text="활성화/비활성화 키:").grid(row=0, column=0, sticky="w", pady=3)
        self.toggle_key = tk.StringVar(value="f1")
        tk.Entry(misc_frame, textvariable=self.toggle_key, width=25).grid(row=0, column=1, sticky="w", padx=5)

        tk.Label(misc_frame, text="처치 후 대기 시간 (초):").grid(row=1, column=0, sticky="w", pady=3)
        self.wait_after_kill = tk.StringVar(value="1.0")
        tk.Entry(misc_frame, textvariable=self.wait_after_kill, width=25).grid(row=1, column=1, sticky="w", padx=5)

        # === 상태 ===
        status_frame = ttk.LabelFrame(self.root, text="상태", padding=10)
        status_frame.pack(fill="x", padx=10, pady=5)

        self.status_label = tk.Label(status_frame, text="⭕ 비활성화",
                                     font=("Arial", 14, "bold"), fg="red")
        self.status_label.pack()

        self.stats_label = tk.Label(status_frame, text="처치: 0마리", font=("Arial", 11))
        self.stats_label.pack()

        # === 로그 ===
        log_frame = ttk.LabelFrame(self.root, text="로그", padding=10)
        log_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.log_text = scrolledtext.ScrolledText(log_frame, height=10, width=50, state='disabled')
        self.log_text.pack(fill="both", expand=True)

        # === 버튼 ===
        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)

        self.start_button = tk.Button(button_frame, text="▶ 시작", bg="green", fg="white",
                                       font=("Arial", 12, "bold"), width=12, command=self.start_listener)
        self.start_button.grid(row=0, column=0, padx=5)

        self.stop_button = tk.Button(button_frame, text="■ 중지", bg="red", fg="white",
                                      font=("Arial", 12, "bold"), width=12, command=self.stop_listener, state="disabled")
        self.stop_button.grid(row=0, column=1, padx=5)

    def log(self, msg):
        """로그 출력"""
        t = time.strftime("%H:%M:%S")
        log_msg = f"[{t}] {msg}\n"

        print(log_msg.strip())

        self.log_text.config(state='normal')
        self.log_text.insert('end', log_msg)
        self.log_text.see('end')
        self.log_text.config(state='disabled')

    def update_status(self):
        """상태 업데이트"""
        if self.active:
            self.status_label.config(text="✅ 활성화 (몹 클릭하면 자동 공격!)", fg="green")
        else:
            self.status_label.config(text="⭕ 비활성화", fg="red")

        self.stats_label.config(text=f"처치: {self.kill_count}마리")

    def attack_sequence(self):
        """자동 공격 시퀀스"""
        if self.attacking:
            return  # 이미 공격 중이면 무시

        self.attacking = True
        self.log("자동 공격 시작!")

        try:
            skills = [k.strip() for k in self.skill_keys.get().split(',')]
            attacks = int(self.attacks_per_mob.get())
            interval = float(self.skill_interval.get())

            for i in range(attacks):
                if not self.active:  # 중간에 비활성화되면 중지
                    break

                skill = random.choice(skills)
                pyautogui.press(skill)
                self.log(f"  스킬 '{skill}' 사용 ({i+1}/{attacks})")
                time.sleep(interval)

            self.kill_count += 1
            self.update_status()
            self.log(f"처치 완료! (총 {self.kill_count}마리)")

            # 대기
            wait_time = float(self.wait_after_kill.get())
            time.sleep(wait_time)

        except Exception as e:
            self.log(f"오류: {e}")

        finally:
            self.attacking = False

    def on_click(self, x, y, button, pressed):
        """마우스 클릭 감지"""
        if not self.active:
            return

        # 왼쪽 클릭만 감지
        if button == mouse.Button.left and pressed:
            # GUI 창 클릭은 무시
            if self.root.winfo_containing(x, y) == self.root:
                return

            self.log(f"몹 클릭 감지: ({x}, {y})")

            # 별도 쓰레드로 공격
            thread = threading.Thread(target=self.attack_sequence, daemon=True)
            thread.start()

    def on_press(self, key):
        """키보드 입력 감지"""
        try:
            toggle_key = self.toggle_key.get().lower()

            # F1~F12 키 처리
            if hasattr(key, 'name'):
                key_name = key.name.lower()
            else:
                key_name = str(key).replace("'", "").lower()

            if key_name == toggle_key:
                self.active = not self.active
                self.update_status()

                if self.active:
                    self.log(f"✅ 활성화! ({toggle_key.upper()} 키로 토글)")
                else:
                    self.log(f"⭕ 비활성화! ({toggle_key.upper()} 키로 토글)")

        except Exception as e:
            pass

    def start_listener(self):
        """리스너 시작"""
        self.log("=" * 50)
        self.log("반자동 사냥 매크로 시작!")
        self.log(f"'{self.toggle_key.get().upper()}' 키를 눌러 활성화하세요!")
        self.log("=" * 50)

        # 마우스 리스너
        self.mouse_listener = mouse.Listener(on_click=self.on_click)
        self.mouse_listener.start()

        # 키보드 리스너
        self.keyboard_listener = keyboard.Listener(on_press=self.on_press)
        self.keyboard_listener.start()

        self.start_button.config(state="disabled")
        self.stop_button.config(state="normal")

    def stop_listener(self):
        """리스너 중지"""
        self.active = False
        self.update_status()

        if self.mouse_listener:
            self.mouse_listener.stop()

        if self.keyboard_listener:
            self.keyboard_listener.stop()

        self.log("매크로 중지됨")

        self.start_button.config(state="normal")
        self.stop_button.config(state="disabled")

if __name__ == "__main__":
    root = tk.Tk()
    app = SemiAutoHuntingGUI(root)
    root.mainloop()
