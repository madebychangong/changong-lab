"""
게임 활동 자동화 모듈
낚시, 채집, 전투 등의 반복 작업 자동화
"""

import pyautogui
import time
import random
from datetime import datetime
from image_utils import ImageRecognition
from advanced_utils import PathNavigator, NPCInteraction, InventoryManager, MobFinder, SkillRotation

class BaseActivity:
    """기본 활동 클래스"""

    def __init__(self, name):
        self.name = name
        self.running = False
        self.img_rec = ImageRecognition(confidence=0.8)
        self.count = 0
        self.start_time = None

    def log(self, message):
        """로그 출력"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] [{self.name}] {message}")

    def random_delay(self, min_sec=0.5, max_sec=1.5):
        """랜덤 딜레이 (사람처럼 보이기 위함)"""
        delay = random.uniform(min_sec, max_sec)
        time.sleep(delay)

    def start(self):
        """활동 시작"""
        self.running = True
        self.count = 0
        self.start_time = time.time()
        self.log(f"{self.name} 시작!")

    def stop(self):
        """활동 중지"""
        self.running = False
        elapsed = time.time() - self.start_time if self.start_time else 0
        self.log(f"{self.name} 종료 - 총 {self.count}회, {elapsed:.1f}초 경과")

    def get_stats(self):
        """통계 정보"""
        elapsed = time.time() - self.start_time if self.start_time else 0
        rate = self.count / (elapsed / 60) if elapsed > 0 else 0
        return {
            "count": self.count,
            "elapsed": elapsed,
            "rate_per_minute": rate
        }


class FishingBot(BaseActivity):
    """낚시 자동화"""

    def __init__(self):
        super().__init__("낚시")
        self.fishing_key = 'f'  # 낚시 키
        self.catch_delay = 3.0  # 낚시 대기 시간 (게임에 따라 조정)

    def fish_once(self):
        """한 번 낚시"""
        # 1. 낚시 시작 (F키 등)
        pyautogui.press(self.fishing_key)
        self.log("낚시 시전...")

        # 2. 물고기 잡을 때까지 대기
        time.sleep(self.catch_delay)

        # 3. 물고기 잡기 (스페이스바 등)
        pyautogui.press('space')
        self.log("물고기 획득!")

        self.count += 1
        self.random_delay(1, 2)

    def run(self, duration=None):
        """
        낚시 시작

        Args:
            duration: 실행 시간 (초), None이면 무한 반복
        """
        self.start()

        try:
            while self.running:
                if duration and (time.time() - self.start_time) > duration:
                    break

                self.fish_once()

        except KeyboardInterrupt:
            pass
        finally:
            self.stop()


class GatheringBot(BaseActivity):
    """채집 자동화"""

    def __init__(self):
        super().__init__("채집")
        self.gather_key = 'e'  # 채집 키
        self.gather_delay = 2.0  # 채집 소요 시간

    def gather_once(self, x=None, y=None):
        """한 번 채집"""
        # 1. 채집물 클릭 또는 지정된 위치 클릭
        if x and y:
            pyautogui.click(x, y)
            self.log(f"위치 ({x}, {y}) 클릭")
        else:
            # 화면 중앙 근처를 랜덤하게 클릭
            screen_width, screen_height = pyautogui.size()
            x = screen_width // 2 + random.randint(-100, 100)
            y = screen_height // 2 + random.randint(-100, 100)
            pyautogui.click(x, y)

        self.random_delay(0.5, 1)

        # 2. 채집 키 누르기
        pyautogui.press(self.gather_key)
        self.log("채집 시작...")

        # 3. 채집 완료 대기
        time.sleep(self.gather_delay)

        self.count += 1
        self.random_delay(0.5, 1.5)

    def run_with_positions(self, positions, duration=None):
        """
        특정 위치들을 순회하며 채집

        Args:
            positions: [(x, y), ...] 채집 위치 리스트
            duration: 실행 시간 (초)
        """
        self.start()

        try:
            pos_index = 0
            while self.running:
                if duration and (time.time() - self.start_time) > duration:
                    break

                # 순환하며 채집
                x, y = positions[pos_index % len(positions)]
                self.gather_once(x, y)

                pos_index += 1

        except KeyboardInterrupt:
            pass
        finally:
            self.stop()

    def run_random(self, duration=None):
        """랜덤 위치 채집"""
        self.start()

        try:
            while self.running:
                if duration and (time.time() - self.start_time) > duration:
                    break

                self.gather_once()

        except KeyboardInterrupt:
            pass
        finally:
            self.stop()


class CombatBot(BaseActivity):
    """전투 자동화 (몹 사냥)"""

    def __init__(self):
        super().__init__("전투")
        self.attack_key = '1'  # 기본 공격 스킬
        self.skill_keys = ['2', '3', '4']  # 추가 스킬들
        self.hp_potion_key = 'q'  # HP 포션
        self.mp_potion_key = 'w'  # MP 포션

    def attack_once(self):
        """한 번 공격"""
        # 기본 공격
        pyautogui.press(self.attack_key)
        self.random_delay(0.3, 0.7)

        # 랜덤으로 스킬 사용 (30% 확률)
        if random.random() < 0.3 and self.skill_keys:
            skill = random.choice(self.skill_keys)
            pyautogui.press(skill)
            self.log(f"스킬 {skill} 사용")
            self.random_delay(0.5, 1)

    def use_potion(self, potion_type='hp'):
        """포션 사용"""
        if potion_type == 'hp':
            pyautogui.press(self.hp_potion_key)
            self.log("HP 포션 사용")
        elif potion_type == 'mp':
            pyautogui.press(self.mp_potion_key)
            self.log("MP 포션 사용")

    def find_and_attack_mob(self, mob_image_path=None):
        """몹 찾아서 공격"""
        # 이미지로 몹 찾기
        if mob_image_path:
            pos = self.img_rec.find_image(mob_image_path)
            if pos:
                pyautogui.click(pos[0], pos[1])
                self.log("몹 타겟 선택")
                self.random_delay(0.5, 1)

        # 공격
        for _ in range(5):  # 5회 공격
            self.attack_once()

        self.count += 1

    def run_combat(self, duration=None):
        """
        전투 시작

        Args:
            duration: 실행 시간 (초)
        """
        self.start()

        try:
            while self.running:
                if duration and (time.time() - self.start_time) > duration:
                    break

                # 계속 공격
                self.attack_once()

        except KeyboardInterrupt:
            pass
        finally:
            self.stop()


class SkillTrainingBot(BaseActivity):
    """숙련도 올리기 자동화"""

    def __init__(self):
        super().__init__("숙련도")
        self.skill_key = '1'  # 숙련도 올릴 스킬

    def use_skill(self):
        """스킬 사용"""
        pyautogui.press(self.skill_key)
        self.log("스킬 사용")
        self.count += 1
        self.random_delay(1, 2)

    def run(self, duration=None):
        """
        숙련도 훈련 시작

        Args:
            duration: 실행 시간 (초)
        """
        self.start()

        try:
            while self.running:
                if duration and (time.time() - self.start_time) > duration:
                    break

                self.use_skill()

        except KeyboardInterrupt:
            pass
        finally:
            self.stop()


# ==================== 고급 Bot 클래스들 ====================


class AdvancedFishingBot(BaseActivity):
    """
    고급 낚시 자동화
    낚시 → 상점 판매 → 낚시터 복귀 루프
    """

    def __init__(self):
        super().__init__("고급낚시")
        self.fishing_key = 'f'
        self.catch_delay = 3.0
        self.fishes_per_trip = 20  # 몇 마리마다 상점 방문

        # 경로 설정 (실제 게임에 맞게 수정 필요)
        self.path_to_shop = []  # [(x, y), ...] 상점으로 가는 경로
        self.path_to_fishing = []  # [(x, y), ...] 낚시터로 돌아오는 경로
        self.shop_npc_pos = (0, 0)  # 상점 NPC 위치
        self.sell_button_pos = (0, 0)  # 판매 버튼 위치

        self.navigator = PathNavigator()
        self.inventory = InventoryManager()

        self.fish_count = 0
        self.sell_count = 0

    def setup_paths(self, path_to_shop, path_to_fishing, shop_npc, sell_button):
        """
        경로 설정

        Args:
            path_to_shop: [(x, y), ...] 상점 경로
            path_to_fishing: [(x, y), ...] 낚시터 경로
            shop_npc: (x, y) 상점 NPC 위치
            sell_button: (x, y) 판매 버튼 위치
        """
        self.path_to_shop = path_to_shop
        self.path_to_fishing = path_to_fishing
        self.shop_npc_pos = shop_npc
        self.sell_button_pos = sell_button
        self.log("경로 설정 완료!")

    def fish_once(self):
        """한 번 낚시"""
        pyautogui.press(self.fishing_key)
        self.log("낚시 시전...")
        time.sleep(self.catch_delay)

        pyautogui.press('space')
        self.fish_count += 1
        self.count += 1
        self.log(f"물고기 획득! (현재: {self.fish_count}마리)")
        self.random_delay(1, 2)

    def go_to_shop_and_sell(self):
        """상점 가서 판매"""
        self.log("상점으로 이동 중...")

        if self.path_to_shop:
            self.navigator.follow_path(self.path_to_shop, delay_per_point=2.0)
        else:
            self.log("⚠️  경로가 설정되지 않았습니다. setup_paths()를 먼저 호출하세요.")
            return

        # 판매
        self.inventory.sell_all_items(self.shop_npc_pos, self.sell_button_pos)
        self.sell_count += 1
        self.log(f"판매 완료! (총 {self.sell_count}회)")

        # 낚시터로 복귀
        self.log("낚시터로 복귀 중...")
        if self.path_to_fishing:
            self.navigator.follow_path(self.path_to_fishing, delay_per_point=2.0)

        self.fish_count = 0

    def run(self, duration=None):
        """낚시 + 판매 루프 시작"""
        self.start()

        try:
            while self.running:
                if duration and (time.time() - self.start_time) > duration:
                    break

                # 낚시
                self.fish_once()

                # 일정 개수마다 상점 방문
                if self.fish_count >= self.fishes_per_trip:
                    self.go_to_shop_and_sell()

        except KeyboardInterrupt:
            pass
        finally:
            self.stop()
            self.log(f"총 판매 횟수: {self.sell_count}")


class AdvancedCombatBot(BaseActivity):
    """
    고급 전투 자동화
    맵에서 몹을 찾아서 자동 사냥
    """

    def __init__(self):
        super().__init__("고급전투")
        self.attack_key = '1'
        self.skill_keys = ['2', '3', '4']
        self.hp_potion_key = 'q'
        self.mp_potion_key = 'w'

        # 몹 탐색 영역 (게임에 맞게 수정)
        self.scan_positions = []  # [(x, y), ...] 몹을 찾을 위치들
        self.mob_image_path = None  # 몹 이미지 파일 경로

        self.mob_finder = MobFinder()
        self.kill_count = 0

    def setup_hunting_area(self, scan_positions, mob_image=None):
        """
        사냥터 설정

        Args:
            scan_positions: [(x, y), ...] 몹 탐색 위치들
            mob_image: 몹 이미지 파일 경로 (옵션)
        """
        self.scan_positions = scan_positions
        self.mob_image_path = mob_image
        self.log("사냥터 설정 완료!")

    def find_and_kill_mob(self):
        """몹 찾아서 처치"""
        # 이미지로 몹 찾기
        if self.mob_image_path:
            mob_positions = self.mob_finder.find_all_mobs(self.mob_image_path)

            if mob_positions:
                self.mob_finder.attack_nearest_mob(mob_positions, self.attack_key)
                self.log("몹 발견! 공격 시작")

                # 몹 처치까지 공격
                for _ in range(10):  # 최대 10회 공격
                    pyautogui.press(self.attack_key)
                    self.random_delay(0.5, 1.0)

                    # 랜덤 스킬 사용
                    if random.random() < 0.4 and self.skill_keys:
                        pyautogui.press(random.choice(self.skill_keys))
                        self.random_delay(0.3, 0.7)

                self.kill_count += 1
                self.count += 1
                self.log(f"몹 처치! (총 {self.kill_count}마리)")
                return True

        # 이미지가 없으면 순회하며 탐색
        if self.scan_positions:
            for x, y in self.scan_positions:
                pyautogui.click(x, y)
                self.random_delay(1, 2)

                # 여기서 탭 키로 타겟팅 시도
                pyautogui.press('tab')
                self.random_delay(0.5, 1.0)

                # 공격
                pyautogui.press(self.attack_key)
                self.random_delay(0.5, 1.0)

        return False

    def run_auto_hunt(self, duration=None):
        """자동 사냥 시작"""
        self.start()

        try:
            while self.running:
                if duration and (time.time() - self.start_time) > duration:
                    break

                self.find_and_kill_mob()
                self.random_delay(1, 2)

        except KeyboardInterrupt:
            pass
        finally:
            self.stop()
            self.log(f"총 처치: {self.kill_count}마리")


class AdvancedSkillTrainingBot(BaseActivity):
    """
    고급 숙련도 훈련
    여러 스킬 순환 + NPC 축복 받기
    """

    def __init__(self):
        super().__init__("고급숙련도")

        # 스킬 설정 (게임에 맞게 수정)
        self.skills = [
            {'key': '1', 'cooldown': 0.0, 'priority': 1},
            {'key': '2', 'cooldown': 2.0, 'priority': 2},
            {'key': '3', 'cooldown': 5.0, 'priority': 3},
        ]

        # NPC 축복 설정
        self.blessing_npc_pos = None  # (x, y)
        self.blessing_interval = 60  # 축복 받을 간격 (초)
        self.last_blessing_time = 0

        self.skill_rotation = SkillRotation(self.skills)
        self.npc_interaction = NPCInteraction()

    def setup_blessing(self, npc_position, interval=60):
        """
        축복 설정

        Args:
            npc_position: (x, y) NPC 위치
            interval: 축복 받을 간격 (초)
        """
        self.blessing_npc_pos = npc_position
        self.blessing_interval = interval
        self.log(f"축복 설정 완료! (간격: {interval}초)")

    def setup_skills(self, skills):
        """
        스킬 설정

        Args:
            skills: [
                {'key': '1', 'cooldown': 0.0, 'priority': 1},
                ...
            ]
        """
        self.skills = skills
        self.skill_rotation = SkillRotation(skills)
        self.log("스킬 설정 완료!")

    def receive_blessing_if_needed(self):
        """필요하면 축복 받기"""
        current_time = time.time()

        if self.blessing_npc_pos and \
           (current_time - self.last_blessing_time) >= self.blessing_interval:

            self.log("축복 받으러 가는 중...")
            self.npc_interaction.receive_blessing(self.blessing_npc_pos)
            self.last_blessing_time = current_time

    def train_once(self):
        """한 번 훈련 (스킬 사용)"""
        # 스킬 순환 사용
        skill_used = self.skill_rotation.use_next_skill()

        if skill_used:
            self.count += 1
            self.random_delay(0.5, 1.0)
        else:
            # 사용 가능한 스킬이 없으면 대기
            time.sleep(0.5)

    def run(self, duration=None):
        """숙련도 훈련 시작"""
        self.start()
        self.last_blessing_time = time.time()

        try:
            while self.running:
                if duration and (time.time() - self.start_time) > duration:
                    break

                # 축복 체크
                self.receive_blessing_if_needed()

                # 스킬 훈련
                self.train_once()

        except KeyboardInterrupt:
            pass
        finally:
            self.stop()
