"""
이미지 인식 기반 자동 사냥
특정 몹만 찾아서 잡기
"""

import pyautogui
import time
import random
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, scrolledtext
import threading
import os

pyautogui.FAILSAFE = True

class ImageHuntingGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("이미지 인식 자동 사냥")
        self.root.geometry("600x700")

        self.running = False
        self.kill_count = 0
        self.mob_image_path = None

        self.create_widgets()

    def create_widgets(self):
        """GUI 구성"""
        # 제목
        title = tk.Label(self.root, text="🎯 이미지 인식 자동 사냥", font=("Arial", 16, "bold"))
        title.pack(pady=10)

        # === 몹 이미지 선택 ===
        image_frame = ttk.LabelFrame(self.root, text="1. 잡을 몹 이미지 선택", padding=10)
        image_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(image_frame, text="잡고 싶은 몹의 스크린샷을 찍어서 선택하세요.").pack(anchor="w", pady=5)

        btn_frame = tk.Frame(image_frame)
        btn_frame.pack(fill="x", pady=5)

        tk.Button(btn_frame, text="📸 스크린샷 찍기 (5초 후)", command=self.take_screenshot,
                  bg="lightblue", font=("Arial", 10)).pack(side="left", padx=5)

        tk.Button(btn_frame, text="📁 이미지 선택", command=self.select_image,
                  bg="lightgreen", font=("Arial", 10)).pack(side="left", padx=5)

        self.image_label = tk.Label(image_frame, text="이미지가 선택되지 않았습니다.", fg="red")
        self.image_label.pack(anchor="w", pady=5)

        # === 검색 영역 설정 ===
        area_frame = ttk.LabelFrame(self.root, text="2. 검색 영역 설정 (선택)", padding=10)
        area_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(area_frame, text="화면 전체를 검색하려면 비워두세요.").pack(anchor="w")

        region_frame = tk.Frame(area_frame)
        region_frame.pack(fill="x", pady=5)

        tk.Label(region_frame, text="X:").grid(row=0, column=0, padx=2)
        self.region_x = tk.StringVar(value="")
        tk.Entry(region_frame, textvariable=self.region_x, width=8).grid(row=0, column=1, padx=2)

        tk.Label(region_frame, text="Y:").grid(row=0, column=2, padx=2)
        self.region_y = tk.StringVar(value="")
        tk.Entry(region_frame, textvariable=self.region_y, width=8).grid(row=0, column=3, padx=2)

        tk.Label(region_frame, text="Width:").grid(row=0, column=4, padx=2)
        self.region_w = tk.StringVar(value="")
        tk.Entry(region_frame, textvariable=self.region_w, width=8).grid(row=0, column=5, padx=2)

        tk.Label(region_frame, text="Height:").grid(row=0, column=6, padx=2)
        self.region_h = tk.StringVar(value="")
        tk.Entry(region_frame, textvariable=self.region_h, width=8).grid(row=0, column=7, padx=2)

        # === 스킬 설정 ===
        skill_frame = ttk.LabelFrame(self.root, text="3. 스킬 설정", padding=10)
        skill_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(skill_frame, text="스킬 키 (쉼표로 구분):").grid(row=0, column=0, sticky="w", pady=3)
        self.skill_keys = tk.StringVar(value="1,2,3")
        tk.Entry(skill_frame, textvariable=self.skill_keys, width=20).grid(row=0, column=1, sticky="w", padx=5)

        tk.Label(skill_frame, text="한 몹당 공격 횟수:").grid(row=1, column=0, sticky="w", pady=3)
        self.attacks_per_mob = tk.StringVar(value="8")
        tk.Entry(skill_frame, textvariable=self.attacks_per_mob, width=20).grid(row=1, column=1, sticky="w", padx=5)

        tk.Label(skill_frame, text="스킬 간격 (초):").grid(row=2, column=0, sticky="w", pady=3)
        self.skill_interval = tk.StringVar(value="0.8")
        tk.Entry(skill_frame, textvariable=self.skill_interval, width=20).grid(row=2, column=1, sticky="w", padx=5)

        # === 검색 설정 ===
        search_frame = ttk.LabelFrame(self.root, text="4. 검색 설정", padding=10)
        search_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(search_frame, text="이미지 인식 정확도 (0.7~0.95):").grid(row=0, column=0, sticky="w", pady=3)
        self.confidence = tk.StringVar(value="0.8")
        tk.Entry(search_frame, textvariable=self.confidence, width=20).grid(row=0, column=1, sticky="w", padx=5)

        tk.Label(search_frame, text="검색 간격 (초):").grid(row=1, column=0, sticky="w", pady=3)
        self.search_interval = tk.StringVar(value="1.0")
        tk.Entry(search_frame, textvariable=self.search_interval, width=20).grid(row=1, column=1, sticky="w", padx=5)

        # === 통계 ===
        stats_frame = ttk.LabelFrame(self.root, text="통계", padding=10)
        stats_frame.pack(fill="x", padx=10, pady=5)

        self.stats_label = tk.Label(stats_frame, text="대기 중...", font=("Arial", 11))
        self.stats_label.pack()

        # === 로그 ===
        log_frame = ttk.LabelFrame(self.root, text="로그", padding=10)
        log_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.log_text = scrolledtext.ScrolledText(log_frame, height=8, width=60, state='disabled')
        self.log_text.pack(fill="both", expand=True)

        # === 버튼 ===
        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)

        self.start_button = tk.Button(button_frame, text="▶ 시작", bg="green", fg="white",
                                       font=("Arial", 12, "bold"), width=12, command=self.start_macro)
        self.start_button.grid(row=0, column=0, padx=5)

        self.stop_button = tk.Button(button_frame, text="■ 중지", bg="red", fg="white",
                                      font=("Arial", 12, "bold"), width=12, command=self.stop_macro, state="disabled")
        self.stop_button.grid(row=0, column=1, padx=5)

    def take_screenshot(self):
        """스크린샷 찍기"""
        self.log("5초 후 스크린샷을 찍습니다. 잡고 싶은 몹에 마우스를 올려두세요!")

        def capture():
            for i in range(5, 0, -1):
                self.log(f"{i}...")
                time.sleep(1)

            # 스크린샷 저장
            if not os.path.exists("mob_images"):
                os.makedirs("mob_images")

            timestamp = time.strftime("%Y%m%d_%H%M%S")
            filename = f"mob_images/mob_{timestamp}.png"

            screenshot = pyautogui.screenshot()
            screenshot.save(filename)

            self.mob_image_path = filename
            self.image_label.config(text=f"✓ {filename}", fg="green")
            self.log(f"스크린샷 저장 완료: {filename}")
            self.log("이제 이미지 편집기로 몹 부분만 잘라내세요!")

        thread = threading.Thread(target=capture, daemon=True)
        thread.start()

    def select_image(self):
        """이미지 파일 선택"""
        filename = filedialog.askopenfilename(
            title="몹 이미지 선택",
            filetypes=[("PNG files", "*.png"), ("All files", "*.*")]
        )

        if filename:
            self.mob_image_path = filename
            self.image_label.config(text=f"✓ {filename}", fg="green")
            self.log(f"이미지 선택됨: {filename}")

    def log(self, msg):
        """로그 출력"""
        t = time.strftime("%H:%M:%S")
        log_msg = f"[{t}] {msg}\n"

        print(log_msg.strip())

        self.log_text.config(state='normal')
        self.log_text.insert('end', log_msg)
        self.log_text.see('end')
        self.log_text.config(state='disabled')

    def update_stats(self):
        """통계 업데이트"""
        text = f"처치: {self.kill_count}마리"
        self.stats_label.config(text=text)

    def find_mob(self):
        """화면에서 몹 찾기"""
        if not self.mob_image_path:
            return None

        try:
            # 검색 영역
            region = None
            if self.region_x.get() and self.region_y.get():
                region = (
                    int(self.region_x.get()),
                    int(self.region_y.get()),
                    int(self.region_w.get()),
                    int(self.region_h.get())
                )

            # 이미지 찾기
            confidence = float(self.confidence.get())
            location = pyautogui.locateOnScreen(
                self.mob_image_path,
                confidence=confidence,
                region=region
            )

            if location:
                center = pyautogui.center(location)
                return (center.x, center.y)

        except Exception as e:
            self.log(f"검색 오류: {e}")

        return None

    def attack_mob(self, mob_pos):
        """몹 공격"""
        x, y = mob_pos

        # 몹 클릭
        self.log(f"몹 발견! ({x}, {y}) 클릭")
        pyautogui.click(x, y)
        time.sleep(0.5)

        # 스킬 사용
        skills = [k.strip() for k in self.skill_keys.get().split(',')]
        attacks = int(self.attacks_per_mob.get())
        interval = float(self.skill_interval.get())

        for i in range(attacks):
            skill = random.choice(skills)
            pyautogui.press(skill)
            time.sleep(interval)

        self.kill_count += 1
        self.update_stats()
        self.log(f"처치 완료! (총 {self.kill_count}마리)")

    def run_macro(self):
        """매크로 실행"""
        self.log("=" * 50)
        self.log("이미지 인식 사냥 시작!")

        if not self.mob_image_path:
            messagebox.showerror("오류", "몹 이미지를 선택하세요!")
            self.stop_macro()
            return

        search_interval = float(self.search_interval.get())

        self.log("5초 후 시작...")
        for i in range(5, 0, -1):
            self.log(f"{i}...")
            time.sleep(1)

        try:
            while self.running:
                # 몹 찾기
                mob_pos = self.find_mob()

                if mob_pos:
                    # 공격
                    self.attack_mob(mob_pos)
                    time.sleep(1.5)
                else:
                    # 못 찾으면 계속 검색
                    self.log("몹 검색 중...")
                    time.sleep(search_interval)

        except Exception as e:
            self.log(f"오류: {e}")
            messagebox.showerror("오류", str(e))

        finally:
            self.log("=" * 50)
            self.log(f"종료! 총 {self.kill_count}마리 처치")
            self.stop_button.config(state="disabled")
            self.start_button.config(state="normal")

    def start_macro(self):
        """매크로 시작"""
        if not self.mob_image_path:
            messagebox.showerror("오류", "몹 이미지를 먼저 선택하세요!")
            return

        self.running = True
        self.start_button.config(state="disabled")
        self.stop_button.config(state="normal")

        thread = threading.Thread(target=self.run_macro, daemon=True)
        thread.start()

    def stop_macro(self):
        """매크로 중지"""
        self.running = False
        self.log("중지 요청...")

if __name__ == "__main__":
    root = tk.Tk()
    app = ImageHuntingGUI(root)
    root.mainloop()
