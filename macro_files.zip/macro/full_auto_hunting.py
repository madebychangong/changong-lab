"""
완전 자동 사냥 매크로
몹 이미지 인식 → 자동 클릭 → 자동 공격 → 자동 이동
"""

import pyautogui
import time
import random
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
import threading
import os
import glob

pyautogui.FAILSAFE = True

class FullAutoHuntingGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("완전 자동 사냥 매크로")
        self.root.geometry("600x800")

        self.running = False
        self.kill_count = 0
        self.mob_images = []
        self.last_move_time = time.time()

        self.create_widgets()
        self.load_mob_images()

    def create_widgets(self):
        """GUI 구성"""
        # 제목
        title = tk.Label(self.root, text="🤖 완전 자동 사냥 매크로", font=("Arial", 16, "bold"))
        title.pack(pady=10)

        # 설명
        desc_frame = tk.Frame(self.root, bg="lightblue", relief="solid", borderwidth=1)
        desc_frame.pack(fill="x", padx=10, pady=5)

        desc_text = """
        🎯 완전 자동화:
        1. mob_targets/ 폴더에 잡을 몹 PNG 이미지 넣기
        2. 시작 버튼 클릭
        3. 게임 창 활성화 (최소화 X)
        4. 자동으로 몹 찾기 → 클릭 → 공격!

        ⚠️ 주의: 게임 창을 최소화하지 마세요!
        """
        tk.Label(desc_frame, text=desc_text, justify="left", bg="lightblue",
                font=("Arial", 9)).pack(padx=10, pady=10)

        # === 몹 이미지 관리 ===
        image_frame = ttk.LabelFrame(self.root, text="몹 이미지 관리", padding=10)
        image_frame.pack(fill="x", padx=10, pady=5)

        btn_frame = tk.Frame(image_frame)
        btn_frame.pack(fill="x", pady=5)

        tk.Button(btn_frame, text="📁 mob_targets 폴더 열기", command=self.open_mob_folder,
                  bg="lightgreen", font=("Arial", 10)).pack(side="left", padx=5)

        tk.Button(btn_frame, text="🔄 이미지 새로고침", command=self.load_mob_images,
                  bg="lightblue", font=("Arial", 10)).pack(side="left", padx=5)

        self.image_list_label = tk.Label(image_frame, text="로딩 중...", fg="gray", justify="left")
        self.image_list_label.pack(anchor="w", pady=5)

        # === 공격 설정 ===
        attack_frame = ttk.LabelFrame(self.root, text="공격 설정", padding=10)
        attack_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(attack_frame, text="기본 공격 키:").grid(row=0, column=0, sticky="w", pady=3)
        self.attack_key = tk.StringVar(value="1")
        tk.Entry(attack_frame, textvariable=self.attack_key, width=25).grid(row=0, column=1, sticky="w", padx=5)

        tk.Label(attack_frame, text="스킬 키 (쉼표로 구분, 선택):").grid(row=1, column=0, sticky="w", pady=3)
        self.skill_keys = tk.StringVar(value="2,3,4")
        tk.Entry(attack_frame, textvariable=self.skill_keys, width=25).grid(row=1, column=1, sticky="w", padx=5)

        tk.Label(attack_frame, text="한 몹당 공격 횟수:").grid(row=2, column=0, sticky="w", pady=3)
        self.attacks_per_mob = tk.StringVar(value="8")
        tk.Entry(attack_frame, textvariable=self.attacks_per_mob, width=25).grid(row=2, column=1, sticky="w", padx=5)

        tk.Label(attack_frame, text="공격 간격 (초):").grid(row=3, column=0, sticky="w", pady=3)
        self.attack_interval = tk.StringVar(value="0.8")
        tk.Entry(attack_frame, textvariable=self.attack_interval, width=25).grid(row=3, column=1, sticky="w", padx=5)

        # 스킬 사용 여부
        self.use_skills = tk.BooleanVar(value=False)
        tk.Checkbutton(attack_frame, text="스킬 사용 (나중에 구현)",
                      variable=self.use_skills, state="disabled").grid(row=4, column=0, columnspan=2, sticky="w", pady=5)

        # === 이동 설정 ===
        move_frame = ttk.LabelFrame(self.root, text="이동 설정", padding=10)
        move_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(move_frame, text="몹 못 찾으면 이동 (초마다):").grid(row=0, column=0, sticky="w", pady=3)
        self.move_interval = tk.StringVar(value="5")
        tk.Entry(move_frame, textvariable=self.move_interval, width=25).grid(row=0, column=1, sticky="w", padx=5)

        tk.Label(move_frame, text="이동 범위 (픽셀):").grid(row=1, column=0, sticky="w", pady=3)
        self.move_range = tk.StringVar(value="200")
        tk.Entry(move_frame, textvariable=self.move_range, width=25).grid(row=1, column=1, sticky="w", padx=5)

        # === 검색 설정 ===
        search_frame = ttk.LabelFrame(self.root, text="검색 설정", padding=10)
        search_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(search_frame, text="이미지 인식 정확도 (0.6~0.95):").grid(row=0, column=0, sticky="w", pady=3)
        self.confidence = tk.StringVar(value="0.75")
        tk.Entry(search_frame, textvariable=self.confidence, width=25).grid(row=0, column=1, sticky="w", padx=5)

        tk.Label(search_frame, text="검색 간격 (초):").grid(row=1, column=0, sticky="w", pady=3)
        self.search_interval = tk.StringVar(value="0.5")
        tk.Entry(search_frame, textvariable=self.search_interval, width=25).grid(row=1, column=1, sticky="w", padx=5)

        # === 통계 ===
        stats_frame = ttk.LabelFrame(self.root, text="통계", padding=10)
        stats_frame.pack(fill="x", padx=10, pady=5)

        self.stats_label = tk.Label(stats_frame, text="대기 중...", font=("Arial", 11, "bold"))
        self.stats_label.pack()

        # === 로그 ===
        log_frame = ttk.LabelFrame(self.root, text="로그", padding=10)
        log_frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.log_text = scrolledtext.ScrolledText(log_frame, height=10, width=60, state='disabled')
        self.log_text.pack(fill="both", expand=True)

        # === 버튼 ===
        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)

        self.start_button = tk.Button(button_frame, text="▶ 시작", bg="green", fg="white",
                                       font=("Arial", 12, "bold"), width=12, command=self.start_macro)
        self.start_button.grid(row=0, column=0, padx=5)

        self.stop_button = tk.Button(button_frame, text="■ 중지", bg="red", fg="white",
                                      font=("Arial", 12, "bold"), width=12, command=self.stop_macro, state="disabled")
        self.stop_button.grid(row=0, column=1, padx=5)

    def open_mob_folder(self):
        """몹 이미지 폴더 열기"""
        if not os.path.exists("mob_targets"):
            os.makedirs("mob_targets")
            self.log("mob_targets 폴더 생성됨")

        # 폴더 열기 (OS별)
        import platform
        if platform.system() == "Windows":
            os.startfile("mob_targets")
        elif platform.system() == "Darwin":  # macOS
            os.system("open mob_targets")
        else:  # Linux
            os.system("xdg-open mob_targets")

        self.log("mob_targets 폴더가 열렸습니다. 몹 PNG 이미지를 넣으세요!")

    def load_mob_images(self):
        """몹 이미지 로딩"""
        if not os.path.exists("mob_targets"):
            os.makedirs("mob_targets")

        self.mob_images = glob.glob("mob_targets/*.png")

        if self.mob_images:
            image_names = [os.path.basename(img) for img in self.mob_images]
            text = f"✓ {len(self.mob_images)}개 이미지 로딩됨:\n" + "\n".join([f"  • {name}" for name in image_names])
            self.image_list_label.config(text=text, fg="green")
            self.log(f"{len(self.mob_images)}개 몹 이미지 로딩 완료")
        else:
            self.image_list_label.config(text="⚠️ mob_targets/ 폴더에 PNG 이미지가 없습니다!", fg="red")
            self.log("몹 이미지가 없습니다. mob_targets/ 폴더에 PNG 파일을 넣으세요.")

    def log(self, msg):
        """로그 출력"""
        t = time.strftime("%H:%M:%S")
        log_msg = f"[{t}] {msg}\n"

        print(log_msg.strip())

        self.log_text.config(state='normal')
        self.log_text.insert('end', log_msg)
        self.log_text.see('end')
        self.log_text.config(state='disabled')

    def update_stats(self):
        """통계 업데이트"""
        text = f"🎯 처치: {self.kill_count}마리 | 🔍 검색 중..."
        self.stats_label.config(text=text)

    def find_mob(self):
        """화면에서 몹 찾기"""
        if not self.mob_images:
            return None

        confidence = float(self.confidence.get())

        for mob_image in self.mob_images:
            try:
                location = pyautogui.locateOnScreen(mob_image, confidence=confidence)
                if location:
                    center = pyautogui.center(location)
                    mob_name = os.path.basename(mob_image)
                    return (center.x, center.y, mob_name)
            except Exception as e:
                pass

        return None

    def attack_mob(self, mob_pos):
        """몹 공격"""
        x, y, mob_name = mob_pos

        # 몹 클릭
        self.log(f"🎯 {mob_name} 발견! ({x}, {y})")
        pyautogui.click(x, y)
        time.sleep(0.5)

        # 공격
        attack_key = self.attack_key.get()
        attacks = int(self.attacks_per_mob.get())
        interval = float(self.attack_interval.get())

        for i in range(attacks):
            if not self.running:
                break

            pyautogui.press(attack_key)
            time.sleep(interval)

        self.kill_count += 1
        self.update_stats()
        self.log(f"✓ {mob_name} 처치! (총 {self.kill_count}마리)")

    def random_move(self):
        """랜덤 이동"""
        current_time = time.time()
        move_interval = float(self.move_interval.get())

        if (current_time - self.last_move_time) >= move_interval:
            screen_width, screen_height = pyautogui.size()
            move_range = int(self.move_range.get())

            # 화면 중앙 근처 랜덤 위치
            center_x = screen_width // 2
            center_y = screen_height // 2

            x = center_x + random.randint(-move_range, move_range)
            y = center_y + random.randint(-move_range, move_range)

            self.log(f"🚶 이동: ({x}, {y})")
            pyautogui.click(x, y)

            self.last_move_time = current_time

    def run_macro(self):
        """매크로 실행"""
        self.log("=" * 60)
        self.log("🤖 완전 자동 사냥 시작!")

        if not self.mob_images:
            messagebox.showerror("오류", "mob_targets/ 폴더에 몹 이미지를 넣으세요!")
            self.stop_macro()
            return

        self.log(f"타겟: {len(self.mob_images)}종류의 몹")
        self.log("5초 후 시작... 게임 창을 활성화하세요!")

        for i in range(5, 0, -1):
            self.log(f"{i}...")
            time.sleep(1)

        search_interval = float(self.search_interval.get())

        try:
            while self.running:
                # 몹 찾기
                mob_pos = self.find_mob()

                if mob_pos:
                    # 공격
                    self.attack_mob(mob_pos)
                    time.sleep(1.0)
                else:
                    # 못 찾으면 이동
                    self.random_move()
                    time.sleep(search_interval)

        except Exception as e:
            self.log(f"오류: {e}")
            messagebox.showerror("오류", str(e))

        finally:
            self.log("=" * 60)
            self.log(f"종료! 총 {self.kill_count}마리 처치")
            self.stop_button.config(state="disabled")
            self.start_button.config(state="normal")

    def start_macro(self):
        """매크로 시작"""
        if not self.mob_images:
            messagebox.showerror("오류", "mob_targets/ 폴더에 몹 PNG 이미지를 넣으세요!")
            self.open_mob_folder()
            return

        self.running = True
        self.start_button.config(state="disabled")
        self.stop_button.config(state="normal")

        thread = threading.Thread(target=self.run_macro, daemon=True)
        thread.start()

    def stop_macro(self):
        """매크로 중지"""
        self.running = False
        self.log("중지 요청...")

if __name__ == "__main__":
    root = tk.Tk()
    app = FullAutoHuntingGUI(root)
    root.mainloop()
