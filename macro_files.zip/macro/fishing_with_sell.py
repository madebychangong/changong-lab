"""
낚시 + 판매 자동화 (당신 게임용)
인벤토리 가득 차면 상점 가서 판매하고 복귀
"""

import pyautogui
import time

# ==================== 설정 (게임에 맞게 수정!) ====================

# 낚시 설정
FISHING_KEY = 'space'          # 낚시 키
FISHING_INTERVAL = 1.5         # 낚시 시도 간격 (초)
FISHES_BEFORE_SELL = 20        # 몇 마리마다 판매할지

# 경로 설정 (마우스 위치 확인으로 좌표 확인!)
PATH_TO_SHOP = [
    # (x, y),  # 1번 지점
    # (x, y),  # 2번 지점
    # (x, y),  # 상점 도착
]

PATH_TO_FISHING = [
    # (x, y),  # 상점에서 출발
    # (x, y),  # 중간
    # (x, y),  # 낚시터 도착
]

# 상점 NPC 및 판매
SHOP_NPC_POS = (0, 0)          # 상점 NPC 위치 (x, y)
SELL_BUTTON_POS = (0, 0)       # 판매 버튼 위치 (x, y)
SELL_CONFIRM_KEY = 'enter'     # 판매 확인 키

# 내구도 수리 (낚시터에서)
REPAIR_NPC_POS = (0, 0)        # 수리 NPC 위치 (x, y)
REPAIR_BUTTON_POS = (0, 0)     # 수리 버튼 위치 (x, y)
REPAIR_EVERY_N_SELLS = 5       # 몇 번 판매마다 수리할지

# ==============================================================

pyautogui.FAILSAFE = True

class FishingWithSellBot:
    def __init__(self):
        self.fish_count = 0
        self.sell_count = 0
        self.total_fish = 0

    def log(self, msg):
        timestamp = time.strftime("%H:%M:%S")
        print(f"[{timestamp}] {msg}")

    def fish_once(self):
        """한 번 낚시"""
        pyautogui.press(FISHING_KEY)
        self.fish_count += 1
        self.total_fish += 1
        self.log(f"낚시 시전 ({self.fish_count}/{FISHES_BEFORE_SELL}마리)")
        time.sleep(FISHING_INTERVAL)

    def move_to(self, x, y, delay=2.0):
        """특정 위치로 이동"""
        pyautogui.click(x, y)
        time.sleep(delay)

    def follow_path(self, path):
        """경로 따라 이동"""
        if not path:
            self.log("⚠️  경로가 설정되지 않았습니다!")
            return

        for i, (x, y) in enumerate(path, 1):
            self.log(f"이동 중... ({i}/{len(path)})")
            self.move_to(x, y)

    def go_to_shop_and_sell(self):
        """상점 가서 판매"""
        self.log("=" * 50)
        self.log("인벤토리 가득! 상점으로 이동 시작")

        # 1. 상점으로 이동
        self.follow_path(PATH_TO_SHOP)

        # 2. 상점 NPC 클릭
        if SHOP_NPC_POS != (0, 0):
            self.log("상점 NPC 클릭")
            pyautogui.click(SHOP_NPC_POS[0], SHOP_NPC_POS[1])
            time.sleep(1)

        # 3. 판매 버튼 클릭
        if SELL_BUTTON_POS != (0, 0):
            self.log("판매 버튼 클릭")
            pyautogui.click(SELL_BUTTON_POS[0], SELL_BUTTON_POS[1])
            time.sleep(1)

        # 4. 확인
        pyautogui.press(SELL_CONFIRM_KEY)
        time.sleep(1)

        # 5. 상점 닫기
        pyautogui.press('esc')
        time.sleep(0.5)

        self.sell_count += 1
        self.log(f"판매 완료! (총 {self.sell_count}회)")

        # 6. 낚시터로 복귀
        self.log("낚시터로 복귀 중...")
        self.follow_path(PATH_TO_FISHING)

        self.fish_count = 0  # 카운트 리셋
        self.log("낚시 재개!")
        self.log("=" * 50)

    def repair_at_fishing_spot(self):
        """낚시터에서 수리"""
        if REPAIR_NPC_POS == (0, 0):
            return

        self.log("무기 수리 중...")

        # 수리 NPC 클릭
        pyautogui.click(REPAIR_NPC_POS[0], REPAIR_NPC_POS[1])
        time.sleep(1)

        # 수리 버튼 클릭
        if REPAIR_BUTTON_POS != (0, 0):
            pyautogui.click(REPAIR_BUTTON_POS[0], REPAIR_BUTTON_POS[1])
            time.sleep(1)

        # 확인
        pyautogui.press('enter')
        time.sleep(1)

        # 닫기
        pyautogui.press('esc')

        self.log("수리 완료!")

    def run(self, duration_minutes=None):
        """낚시 + 판매 루프 시작"""
        self.log("낚시 + 판매 자동화 시작!")
        self.log(f"설정: {FISHES_BEFORE_SELL}마리마다 판매")

        if duration_minutes:
            self.log(f"실행 시간: {duration_minutes}분")

        start_time = time.time()

        try:
            while True:
                # 시간 체크
                if duration_minutes:
                    elapsed = (time.time() - start_time) / 60
                    if elapsed >= duration_minutes:
                        break

                # 낚시
                self.fish_once()

                # 인벤토리 가득 찼으면 판매
                if self.fish_count >= FISHES_BEFORE_SELL:
                    self.go_to_shop_and_sell()

                    # 일정 주기로 수리
                    if self.sell_count % REPAIR_EVERY_N_SELLS == 0:
                        self.repair_at_fishing_spot()

        except KeyboardInterrupt:
            self.log("중지됨 (Ctrl+C)")

        finally:
            self.log("=" * 50)
            self.log(f"종료! 총 낚시: {self.total_fish}마리, 판매: {self.sell_count}회")

# ==================== 실행 ====================
if __name__ == "__main__":
    print("=" * 60)
    print("낚시 + 판매 자동화")
    print("=" * 60)
    print()
    print("⚠️  먼저 설정을 확인하세요!")
    print("   - 경로 좌표 (PATH_TO_SHOP, PATH_TO_FISHING)")
    print("   - 상점 NPC 위치 (SHOP_NPC_POS)")
    print("   - 판매 버튼 위치 (SELL_BUTTON_POS)")
    print()
    print("💡 python macro.py → 5번으로 좌표 확인!")
    print()

    duration = input("실행 시간 (분, 무제한은 엔터): ").strip()
    duration = int(duration) if duration else None

    print("\n3초 후 시작... 게임 캐릭터를 낚시터에 위치시키세요!")
    time.sleep(3)

    bot = FishingWithSellBot()
    bot.run(duration_minutes=duration)
