"""
간단한 테스트 스크립트
실제 게임에서 기본 기능들이 작동하는지 테스트
"""

import pyautogui
import time

print("=" * 60)
print("게임 매크로 테스트")
print("=" * 60)
print()
print("주의: 게임 창을 활성화한 상태에서 테스트하세요!")
print("중지하려면 마우스를 화면 모서리로 이동하세요.")
print()

# Failsafe 활성화
pyautogui.FAILSAFE = True

# ==================== 테스트 1: 키 입력 ====================
def test_key_press():
    """키 입력 테스트"""
    print("\n[테스트 1] 키 입력 테스트")
    test_key = input("테스트할 키를 입력하세요 (예: f, space, 1): ").strip()

    print(f"3초 후에 '{test_key}' 키를 한 번 누릅니다...")
    time.sleep(3)

    pyautogui.press(test_key)
    print(f"✓ '{test_key}' 키를 눌렀습니다!")
    print("게임에서 해당 키가 눌렸나요? (Y/N)")

# ==================== 테스트 2: 마우스 클릭 ====================
def test_mouse_click():
    """마우스 클릭 테스트"""
    print("\n[테스트 2] 마우스 클릭 테스트")
    x = input("X 좌표: ").strip()
    y = input("Y 좌표: ").strip()

    if not x or not y:
        print("좌표를 입력하지 않았습니다.")
        return

    x, y = int(x), int(y)

    print(f"3초 후에 ({x}, {y}) 위치를 클릭합니다...")
    time.sleep(3)

    pyautogui.click(x, y)
    print(f"✓ ({x}, {y})를 클릭했습니다!")
    print("게임에서 해당 위치가 클릭되었나요? (Y/N)")

# ==================== 테스트 3: 간단한 낚시 시뮬레이션 ====================
def test_fishing_simple():
    """간단한 낚시 동작 테스트"""
    print("\n[테스트 3] 낚시 동작 테스트")
    print("게임의 낚시 방식:")
    fishing_key = input("  낚시 시작 키 (예: f): ").strip()
    catch_key = input("  잡기 키 (예: space): ").strip()
    wait_time = input("  대기 시간 (초, 예: 3): ").strip()

    if not fishing_key or not catch_key or not wait_time:
        print("정보를 입력하지 않았습니다.")
        return

    wait_time = float(wait_time)

    print("\n5초 후 낚시를 시작합니다. 게임 캐릭터를 낚시터에 위치시키세요!")
    time.sleep(5)

    print(f"1. '{fishing_key}' 키 누르기 (낚시 시작)")
    pyautogui.press(fishing_key)

    print(f"2. {wait_time}초 대기 중...")
    time.sleep(wait_time)

    print(f"3. '{catch_key}' 키 누르기 (잡기)")
    pyautogui.press(catch_key)

    print("\n✓ 낚시 동작 완료!")
    print("물고기가 잡혔나요? (Y/N)")

# ==================== 테스트 4: 반복 클릭 ====================
def test_repeat_click():
    """특정 위치를 반복 클릭 테스트"""
    print("\n[테스트 4] 반복 클릭 테스트")
    x = input("X 좌표: ").strip()
    y = input("Y 좌표: ").strip()
    count = input("몇 번 클릭할까요? (예: 5): ").strip()

    if not x or not y or not count:
        print("정보를 입력하지 않았습니다.")
        return

    x, y, count = int(x), int(y), int(count)

    print(f"3초 후 ({x}, {y})를 {count}번 클릭합니다...")
    time.sleep(3)

    for i in range(count):
        pyautogui.click(x, y)
        print(f"  클릭 {i+1}/{count}")
        time.sleep(0.5)

    print("✓ 반복 클릭 완료!")

# ==================== 테스트 5: 경로 이동 ====================
def test_path_movement():
    """경로 이동 테스트"""
    print("\n[테스트 5] 경로 이동 테스트")
    print("3개 지점을 순서대로 클릭합니다.")

    points = []
    for i in range(3):
        x = input(f"  {i+1}번 지점 X: ").strip()
        y = input(f"  {i+1}번 지점 Y: ").strip()
        if x and y:
            points.append((int(x), int(y)))

    if len(points) < 2:
        print("최소 2개 지점이 필요합니다.")
        return

    print(f"\n3초 후 {len(points)}개 지점을 순서대로 이동합니다...")
    time.sleep(3)

    for i, (x, y) in enumerate(points, 1):
        print(f"  {i}번 지점: ({x}, {y}) 클릭")
        pyautogui.click(x, y)
        time.sleep(2)

    print("✓ 경로 이동 완료!")

# ==================== 메인 메뉴 ====================
if __name__ == "__main__":
    while True:
        print("\n" + "=" * 60)
        print("테스트 메뉴")
        print("=" * 60)
        print("1. 키 입력 테스트")
        print("2. 마우스 클릭 테스트")
        print("3. 낚시 동작 테스트")
        print("4. 반복 클릭 테스트")
        print("5. 경로 이동 테스트")
        print("0. 종료")
        print()

        choice = input("선택: ").strip()

        if choice == "1":
            test_key_press()
        elif choice == "2":
            test_mouse_click()
        elif choice == "3":
            test_fishing_simple()
        elif choice == "4":
            test_repeat_click()
        elif choice == "5":
            test_path_movement()
        elif choice == "0":
            print("종료합니다.")
            break
        else:
            print("잘못된 선택입니다.")

        input("\n엔터를 눌러 계속...")
