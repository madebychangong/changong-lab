"""
일랜시아 스타일 게임용 낚시 매크로 (GUI 설정)
"""

import pyautogui
import time
import random
import tkinter as tk
from tkinter import ttk, messagebox
import threading

pyautogui.FAILSAFE = True

class FishingMacroGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("낚시 매크로 설정")
        self.root.geometry("500x700")

        self.running = False
        self.fish_count = 0
        self.total_fish = 0
        self.sell_count = 0

        self.create_widgets()

    def create_widgets(self):
        """GUI 구성"""
        # 제목
        title = tk.Label(self.root, text="🎣 낚시 자동화 설정", font=("Arial", 16, "bold"))
        title.pack(pady=10)

        # === 기본 설정 ===
        basic_frame = ttk.LabelFrame(self.root, text="기본 설정", padding=10)
        basic_frame.pack(fill="x", padx=10, pady=5)

        # 낚시 간격
        tk.Label(basic_frame, text="낚시 간격 (초):").grid(row=0, column=0, sticky="w", pady=3)
        self.fishing_interval = tk.StringVar(value="3.0")
        tk.Entry(basic_frame, textvariable=self.fishing_interval, width=10).grid(row=0, column=1, sticky="w")

        # 몇 마리마다 팔지
        tk.Label(basic_frame, text="몇 마리마다 판매:").grid(row=1, column=0, sticky="w", pady=3)
        self.sell_interval = tk.StringVar(value="20")
        tk.Entry(basic_frame, textvariable=self.sell_interval, width=10).grid(row=1, column=1, sticky="w")

        # 낚시대 슬롯 번호
        tk.Label(basic_frame, text="낚시대 슬롯 (1~0):").grid(row=2, column=0, sticky="w", pady=3)
        self.rod_slot = tk.StringVar(value="1")
        tk.Entry(basic_frame, textvariable=self.rod_slot, width=10).grid(row=2, column=1, sticky="w")

        # === 상점 설정 ===
        shop_frame = ttk.LabelFrame(self.root, text="상점 설정", padding=10)
        shop_frame.pack(fill="x", padx=10, pady=5)

        # 상점 열기 명령어
        tk.Label(shop_frame, text="상점 명령어:").grid(row=0, column=0, sticky="w", pady=3)
        self.shop_command = tk.StringVar(value="/상점")
        tk.Entry(shop_frame, textvariable=self.shop_command, width=20).grid(row=0, column=1, sticky="w")

        # 판매 키
        tk.Label(shop_frame, text="판매 키:").grid(row=1, column=0, sticky="w", pady=3)
        self.sell_key = tk.StringVar(value="s")
        tk.Entry(shop_frame, textvariable=self.sell_key, width=10).grid(row=1, column=1, sticky="w")

        # 구매 키
        tk.Label(shop_frame, text="구매 키:").grid(row=2, column=0, sticky="w", pady=3)
        self.buy_key = tk.StringVar(value="b")
        tk.Entry(shop_frame, textvariable=self.buy_key, width=10).grid(row=2, column=1, sticky="w")

        # 낚시대 구매 개수
        tk.Label(shop_frame, text="낚시대 구매 개수:").grid(row=3, column=0, sticky="w", pady=3)
        self.rod_buy_count = tk.StringVar(value="5")
        tk.Entry(shop_frame, textvariable=self.rod_buy_count, width=10).grid(row=3, column=1, sticky="w")

        # === 경로 설정 ===
        path_frame = ttk.LabelFrame(self.root, text="이동 경로 (좌표)", padding=10)
        path_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(path_frame, text="낚시터 → 상점 경로:").grid(row=0, column=0, sticky="w", pady=3)
        self.path_to_shop = tk.Text(path_frame, height=3, width=40)
        self.path_to_shop.grid(row=1, column=0, columnspan=2, pady=3)
        self.path_to_shop.insert("1.0", "500,400\n600,450\n700,500")

        tk.Label(path_frame, text="상점 → 낚시터 경로:").grid(row=2, column=0, sticky="w", pady=3)
        self.path_to_fishing = tk.Text(path_frame, height=3, width=40)
        self.path_to_fishing.grid(row=3, column=0, columnspan=2, pady=3)
        self.path_to_fishing.insert("1.0", "700,500\n600,450\n500,400")

        # === 통계 ===
        stats_frame = ttk.LabelFrame(self.root, text="통계", padding=10)
        stats_frame.pack(fill="x", padx=10, pady=5)

        self.stats_label = tk.Label(stats_frame, text="대기 중...", font=("Arial", 10))
        self.stats_label.pack()

        # === 버튼 ===
        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)

        self.start_button = tk.Button(button_frame, text="▶ 시작", bg="green", fg="white",
                                       font=("Arial", 12, "bold"), width=10, command=self.start_macro)
        self.start_button.grid(row=0, column=0, padx=5)

        self.stop_button = tk.Button(button_frame, text="■ 중지", bg="red", fg="white",
                                      font=("Arial", 12, "bold"), width=10, command=self.stop_macro, state="disabled")
        self.stop_button.grid(row=0, column=1, padx=5)

        # 도움말
        help_text = "💡 Tip: python macro.py → 5번으로 좌표 확인!"
        tk.Label(self.root, text=help_text, fg="gray").pack(pady=5)

    def parse_path(self, text):
        """경로 텍스트를 좌표 리스트로 변환"""
        lines = text.strip().split('\n')
        path = []
        for line in lines:
            if ',' in line:
                x, y = line.split(',')
                path.append((int(x.strip()), int(y.strip())))
        return path

    def log(self, msg):
        """로그 출력"""
        t = time.strftime("%H:%M:%S")
        print(f"[{t}] {msg}")

    def update_stats(self):
        """통계 업데이트"""
        text = f"낚시: {self.fish_count}/{self.sell_interval.get()} | 총: {self.total_fish}마리 | 판매: {self.sell_count}회"
        self.stats_label.config(text=text)

    def fish_once(self):
        """한 번 낚시"""
        # 낚시대 장착 (슬롯 번호)
        pyautogui.press(self.rod_slot.get())
        time.sleep(0.3)

        # 낚시 시작
        pyautogui.press('space')
        self.log(f"낚시 시전... ({self.fish_count + 1}번째)")

        # 대기
        interval = float(self.fishing_interval.get())
        time.sleep(interval + random.uniform(-0.3, 0.3))

        self.fish_count += 1
        self.total_fish += 1
        self.update_stats()

    def move_along_path(self, path):
        """경로 따라 이동"""
        for i, (x, y) in enumerate(path, 1):
            self.log(f"이동 {i}/{len(path)}: ({x}, {y})")
            pyautogui.click(x, y)
            time.sleep(2.0 + random.uniform(-0.3, 0.3))

    def sell_and_buy(self):
        """상점에서 판매 및 구매"""
        self.log("=" * 50)
        self.log("상점으로 이동 중...")

        # 1. 상점으로 이동
        path_to_shop = self.parse_path(self.path_to_shop.get("1.0", "end"))
        self.move_along_path(path_to_shop)

        # 2. 상점 열기 (명령어)
        self.log(f"상점 열기: {self.shop_command.get()}")
        pyautogui.press('enter')  # 채팅창 열기
        time.sleep(0.5)
        pyautogui.write(self.shop_command.get(), interval=0.05)
        time.sleep(0.3)
        pyautogui.press('enter')  # 전송
        time.sleep(1.5)

        # 3. 판매
        self.log(f"판매 키 '{self.sell_key.get()}' 누르기")
        pyautogui.press(self.sell_key.get())
        time.sleep(1.0)
        pyautogui.press('enter')  # 확인
        time.sleep(1.0)

        # 4. 구매 (낚시대)
        buy_count = int(self.rod_buy_count.get())
        self.log(f"낚시대 {buy_count}개 구매")
        pyautogui.press(self.buy_key.get())
        time.sleep(0.5)

        for _ in range(buy_count):
            pyautogui.press('enter')  # 구매
            time.sleep(0.3)

        # 5. 상점 닫기
        pyautogui.press('esc')
        time.sleep(0.5)

        self.sell_count += 1
        self.log(f"판매 완료! (총 {self.sell_count}회)")

        # 6. 낚시터로 복귀
        self.log("낚시터로 복귀 중...")
        path_to_fishing = self.parse_path(self.path_to_fishing.get("1.0", "end"))
        self.move_along_path(path_to_fishing)

        self.fish_count = 0
        self.update_stats()
        self.log("낚시 재개!")
        self.log("=" * 50)

    def run_macro(self):
        """매크로 실행 (별도 쓰레드)"""
        self.log("매크로 시작!")

        # 5초 대기 (게임 준비)
        for i in range(5, 0, -1):
            self.log(f"{i}초 후 시작...")
            time.sleep(1)

        try:
            while self.running:
                # 낚시
                self.fish_once()

                # 판매 타이밍
                sell_interval = int(self.sell_interval.get())
                if self.fish_count >= sell_interval:
                    self.sell_and_buy()

                time.sleep(0.5)

        except Exception as e:
            self.log(f"오류: {e}")
            messagebox.showerror("오류", str(e))

        finally:
            self.log("매크로 중지됨")
            self.stop_button.config(state="disabled")
            self.start_button.config(state="normal")

    def start_macro(self):
        """매크로 시작"""
        # 검증
        try:
            float(self.fishing_interval.get())
            int(self.sell_interval.get())
        except ValueError:
            messagebox.showerror("오류", "숫자를 올바르게 입력하세요!")
            return

        self.running = True
        self.start_button.config(state="disabled")
        self.stop_button.config(state="normal")

        # 별도 쓰레드로 실행
        thread = threading.Thread(target=self.run_macro, daemon=True)
        thread.start()

    def stop_macro(self):
        """매크로 중지"""
        self.running = False
        self.log("중지 요청됨...")

if __name__ == "__main__":
    root = tk.Tk()
    app = FishingMacroGUI(root)
    root.mainloop()
