"""
당신의 게임에 맞춘 간단한 매크로
직접 수정해서 사용하세요!
"""

import pyautogui
import time

# ==================== 여기를 게임에 맞게 수정! ====================

# 낚시 설정
FISHING_KEY = 'r'      # 낚시 시작 키 (게임에 맞게 변경!)
CATCH_KEY = 'space'    # 물고기 잡기 키
FISHING_WAIT = 5.0     # 낚시 대기 시간 (초)

# 전투 설정
ATTACK_KEY = '1'       # 기본 공격 키
SKILL_KEYS = ['2', '3', '4']  # 스킬 키들

# 숙련도 설정
TRAINING_KEY = '1'     # 훈련할 스킬 키
TRAINING_DELAY = 2.0   # 스킬 사용 간격

# ==============================================================

pyautogui.FAILSAFE = True

def simple_fishing(times=10):
    """간단한 낚시 - 정해진 횟수만큼"""
    print(f"{times}번 낚시 시작! (화면 모서리로 중지)")
    print("3초 후 시작...")
    time.sleep(3)

    for i in range(times):
        print(f"\n[{i+1}/{times}] 낚시 시작...")

        # 1. 낚시 시작
        pyautogui.press(FISHING_KEY)
        print(f"  → '{FISHING_KEY}' 키 누름")

        # 2. 대기
        print(f"  → {FISHING_WAIT}초 대기 중...")
        time.sleep(FISHING_WAIT)

        # 3. 잡기
        pyautogui.press(CATCH_KEY)
        print(f"  → '{CATCH_KEY}' 키 누름 (잡기)")

        time.sleep(1)

    print(f"\n완료! 총 {times}마리 낚시")

def simple_training(minutes=5):
    """간단한 숙련도 훈련"""
    print(f"{minutes}분 동안 훈련 시작!")
    print("3초 후 시작...")
    time.sleep(3)

    start_time = time.time()
    count = 0

    while (time.time() - start_time) < (minutes * 60):
        pyautogui.press(TRAINING_KEY)
        count += 1
        print(f"[{count}] '{TRAINING_KEY}' 스킬 사용")
        time.sleep(TRAINING_DELAY)

    print(f"\n완료! 총 {count}회 스킬 사용")

def simple_combat(duration_minutes=5):
    """간단한 전투 - 계속 공격"""
    print(f"{duration_minutes}분 동안 전투 시작!")
    print("3초 후 시작... (먼저 몹을 타겟팅하세요!)")
    time.sleep(3)

    start_time = time.time()

    while (time.time() - start_time) < (duration_minutes * 60):
        # 기본 공격
        pyautogui.press(ATTACK_KEY)
        time.sleep(0.5)

        # 가끔 스킬 사용
        import random
        if random.random() < 0.3:  # 30% 확률
            skill = random.choice(SKILL_KEYS)
            pyautogui.press(skill)
            time.sleep(0.5)

    print("\n전투 완료!")

# ==================== 실행 ====================
if __name__ == "__main__":
    print("=" * 60)
    print("간단한 게임 매크로 (게임에 맞게 수정하세요!)")
    print("=" * 60)
    print("\n선택:")
    print("1. 낚시 (10회)")
    print("2. 숙련도 훈련 (5분)")
    print("3. 전투 (5분)")
    print()

    choice = input("선택: ").strip()

    if choice == "1":
        simple_fishing(times=10)
    elif choice == "2":
        simple_training(minutes=5)
    elif choice == "3":
        simple_combat(duration_minutes=5)
    else:
        print("잘못된 선택")

    print("\n📝 파일 위쪽의 설정을 게임에 맞게 수정하세요!")
    print("   FISHING_KEY, ATTACK_KEY 등등...")
