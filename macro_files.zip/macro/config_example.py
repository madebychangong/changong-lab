"""
게임 매크로 설정 파일 예시
이 파일을 복사해서 config.py로 저장하고 게임에 맞게 수정하세요.
"""

# ==================== 낚시 설정 ====================
FISHING_CONFIG = {
    'fishing_key': 'f',      # 낚시 시작 키
    'catch_key': 'space',    # 물고기 잡기 키
    'cast_delay': 3.0,       # 낚시 대기 시간 (초)
    'min_delay': 1.0,        # 최소 랜덤 딜레이
    'max_delay': 2.0,        # 최대 랜덤 딜레이
}

# ==================== 채집 설정 ====================
GATHERING_CONFIG = {
    'gather_key': 'e',       # 채집 키
    'gather_delay': 2.0,     # 채집 소요 시간
    'positions': [           # 순회할 채집 위치 (x, y)
        (500, 300),
        (600, 350),
        (550, 400),
    ],
    'min_delay': 0.5,
    'max_delay': 1.5,
}

# ==================== 전투 설정 ====================
COMBAT_CONFIG = {
    'attack_key': '1',           # 기본 공격 키
    'skill_keys': ['2', '3', '4'], # 스킬 키 리스트
    'hp_potion_key': 'q',        # HP 포션 키
    'mp_potion_key': 'w',        # MP 포션 키
    'skill_use_chance': 0.3,     # 스킬 사용 확률 (0.0 ~ 1.0)
    'attack_count': 5,           # 한 번에 공격 횟수
    'min_delay': 0.3,
    'max_delay': 0.7,
}

# ==================== 숙련도 설정 ====================
SKILL_TRAINING_CONFIG = {
    'skill_key': '1',        # 훈련할 스킬 키
    'use_delay': 1.5,        # 스킬 사용 간격
    'min_delay': 1.0,
    'max_delay': 2.0,
}

# ==================== 이미지 인식 설정 ====================
IMAGE_RECOGNITION_CONFIG = {
    'confidence': 0.8,       # 이미지 매칭 정확도 (0.0 ~ 1.0)
    'screenshot_dir': 'screenshots',  # 스크린샷 저장 폴더
}

# ==================== HP/MP 체크 설정 ====================
# 특정 위치의 색상으로 HP/MP 체크
HP_CHECK = {
    'enabled': False,         # HP 체크 활성화
    'position': (100, 50),   # HP 바 위치 (x, y)
    'low_color': (255, 0, 0),  # HP 낮을 때 색상 (빨강)
    'use_potion_threshold': 10,  # 색상 오차 허용 범위
}

MP_CHECK = {
    'enabled': False,         # MP 체크 활성화
    'position': (100, 70),   # MP 바 위치 (x, y)
    'low_color': (0, 0, 255),  # MP 낮을 때 색상 (파랑)
    'use_potion_threshold': 10,
}

# ==================== 일반 설정 ====================
GENERAL_CONFIG = {
    'failsafe': True,        # Failsafe 기능 (마우스 모서리로 중지)
    'stop_key': 'F9',        # 중지 키
    'log_enabled': True,     # 로그 출력 활성화
}

# ==================== 게임별 커스텀 시퀀스 ====================
# 복잡한 작업 시퀀스를 정의할 수 있습니다
CUSTOM_SEQUENCES = {
    'buff_routine': [
        {'action': 'press', 'key': '5', 'delay': 1.0},  # 버프 1
        {'action': 'press', 'key': '6', 'delay': 1.0},  # 버프 2
        {'action': 'press', 'key': '7', 'delay': 1.0},  # 버프 3
    ],
    'inventory_sort': [
        {'action': 'press', 'key': 'i', 'delay': 0.5},  # 인벤토리 열기
        {'action': 'click', 'pos': (800, 600), 'delay': 0.5},  # 정렬 버튼
        {'action': 'press', 'key': 'esc', 'delay': 0.5},  # 닫기
    ],
}

# ==================== 사용 예시 ====================
"""
# config.py를 만들고 나서 이렇게 사용:

from config import FISHING_CONFIG, COMBAT_CONFIG

# 낚시 봇에 설정 적용
fishing_bot = FishingBot()
fishing_bot.fishing_key = FISHING_CONFIG['fishing_key']
fishing_bot.catch_delay = FISHING_CONFIG['cast_delay']

# 전투 봇에 설정 적용
combat_bot = CombatBot()
combat_bot.attack_key = COMBAT_CONFIG['attack_key']
combat_bot.skill_keys = COMBAT_CONFIG['skill_keys']
"""
