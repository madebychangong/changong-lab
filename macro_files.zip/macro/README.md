# RPG 게임 매크로 🎮

싱글 플레이 RPG 게임 자동화 스크립트

## 📋 기능

- ✅ **낚시 자동화** - 반복적인 낚시 작업 자동화
- ✅ **채집 자동화** - 재료 채집 자동화 (랜덤/특정 위치)
- ✅ **전투 자동화** - 몹 사냥 및 스킬 사용
- ✅ **숙련도 훈련** - 스킬 숙련도 올리기
- ✅ **이미지 인식** - 화면에서 버튼/아이템 찾기
- ✅ **마우스 위치 확인** - 좌표 및 색상 정보 확인
- ✅ **스크린샷 저장** - 게임 화면 캡처

## 🚀 설치

```bash
pip install -r requirements.txt
```

## 📖 사용법

### 기본 실행

```bash
python macro.py
```

메뉴에서 원하는 기능을 선택하세요:

```
1. 낚시 자동화
2. 채집 자동화
3. 전투 자동화 (몹 사냥)
4. 숙련도 훈련
5. 마우스 위치 확인
6. 스크린샷 저장
```

### 1️⃣ 낚시 자동화

- **낚시 키**: F
- **잡기 키**: SPACE
- 실행 시간을 분 단위로 설정 가능

### 2️⃣ 채집 자동화

**모드 1: 랜덤 위치 채집**
- 화면 중앙 근처를 랜덤하게 클릭하여 채집

**모드 2: 특정 위치 순회**
- `activities.py`에서 positions 리스트를 수정하여 사용

### 3️⃣ 전투 자동화

- **공격 키**: 1 (기본), 2, 3, 4 (스킬)
- **HP 포션**: Q
- **MP 포션**: W

### 4️⃣ 숙련도 훈련

- **스킬 키**: 1
- 반복적으로 스킬을 사용하여 숙련도 상승

### 5️⃣ 마우스 위치 확인

게임에서 클릭할 위치의 좌표와 색상을 실시간으로 확인합니다.
- Ctrl+C로 종료

### 6️⃣ 스크린샷

게임 화면을 `screenshots/` 폴더에 저장합니다.

## ⚙️ 커스터마이징

### 키 설정 변경

`activities.py` 파일을 열어서 각 Bot 클래스의 키 설정을 수정하세요:

```python
# 낚시 키 변경
class FishingBot:
    def __init__(self):
        self.fishing_key = 'f'  # ← 원하는 키로 변경

# 전투 스킬 키 변경
class CombatBot:
    def __init__(self):
        self.attack_key = '1'  # 기본 공격
        self.skill_keys = ['2', '3', '4']  # 스킬들
```

### 채집 위치 설정

`macro.py`의 88번째 줄 근처에서 positions 수정:

```python
positions = [(500, 300), (600, 350), (550, 400)]  # 실제 좌표로 변경
```

마우스 위치 확인 기능(메뉴 5번)으로 좌표를 확인할 수 있습니다.

### 타이밍 조정

`activities.py`에서 각 활동의 딜레이 시간을 조정:

```python
class FishingBot:
    def __init__(self):
        self.catch_delay = 3.0  # 낚시 대기 시간 (초)

class GatheringBot:
    def __init__(self):
        self.gather_delay = 2.0  # 채집 소요 시간 (초)
```

## 🔧 고급 기능

### 이미지 인식 사용

특정 버튼이나 아이템을 찾아서 클릭하려면:

```python
from image_utils import ImageRecognition

img_rec = ImageRecognition(confidence=0.8)

# 이미지 찾기
pos = img_rec.find_image('button.png')
if pos:
    pyautogui.click(pos[0], pos[1])

# 이미지 나타날 때까지 대기
pos = img_rec.wait_for_image('item.png', timeout=10)

# 색상으로 감지
is_match = img_rec.is_color_match(x=100, y=200, target_color=(255, 0, 0))
```

## ⌨️ 단축키

- **F9**: 실행 중인 매크로 중지
- **마우스를 화면 모서리로**: 긴급 중지 (failsafe)
- **Ctrl+C**: 터미널에서 강제 종료

## 📁 프로젝트 구조

```
macro/
├── macro.py           # 메인 실행 파일
├── activities.py      # 활동별 Bot 클래스
├── image_utils.py     # 이미지 인식 유틸
├── requirements.txt   # 필요한 라이브러리
├── README.md         # 이 파일
└── screenshots/      # 스크린샷 저장 폴더
```

## ⚠️ 주의사항

- **싱글 플레이 게임 전용** - 개인 학습 목적으로만 사용
- **온라인 게임 사용 금지** - 이용약관 위반 및 계정 정지 위험
- 게임 이용약관을 반드시 확인하세요
- 매크로 사용은 본인 책임입니다

## 🛠️ 문제 해결

### pyautogui가 동작하지 않음
- Windows: 관리자 권한으로 실행
- Linux: X11 환경 필요

### 이미지 인식이 안됨
- confidence 값을 낮춰보세요 (0.7 정도)
- 스크린샷을 찍어서 정확한 이미지를 사용하세요

### F9 키가 작동 안함
- keyboard 라이브러리 권한 문제일 수 있음
- Ctrl+C로 대신 종료 가능
